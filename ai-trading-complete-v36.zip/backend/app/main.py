from fastapi import FastAPI
from .api import router as core_router
from .api_v3 import router as v3_router
from .api_v5 import router as v5_router
from .api_v6 import router as v6_router
from .api_v8 import router as v8_router
from .api_v9 import router as v9_router
from .api_v10 import router as v10_router
from .api_v11 import router as v11_router
from .api_v12 import router as v12_router
from .api_v13 import router as v13_router
from .api_v14 import router as v14_router
from .api_v15 import router as v15_router
from .api_v16 import router as v16_router
from .api_v19 import router as v19_router
from .api_v23 import router as v23_router
from .api_v24 import router as v24_router
from .api_v25 import router as v25_router
from .api_v26 import router as v26_router
from .api_v27 import router as v27_router
from .api_v28 import router as v28_router
from .api_v29 import router as v29_router
from .api_v30 import router as v30_router
from .security_v30 import policy
from . import db
from .api_v32 import router as v32_router
from .api_v33 import router as v33_router
from .api_v34 import router as v34_router
from .api_v35 import router as v35_router
from .api_v36 import router as v36_router
app=FastAPI(title="AI Trading — Paper System",version="36.0")
app.include_router(core_router)
app.include_router(v3_router)
app.include_router(v5_router)
app.include_router(v6_router)
app.include_router(v8_router)
app.include_router(v9_router)
app.include_router(v10_router)
app.include_router(v11_router)
app.include_router(v12_router)
app.include_router(v13_router)
app.include_router(v14_router)
app.include_router(v15_router)
app.include_router(v16_router)
app.include_router(v19_router)
app.include_router(v23_router)
app.include_router(v24_router)
app.include_router(v25_router)
app.include_router(v26_router)
app.include_router(v27_router)
app.include_router(v28_router)
app.include_router(v29_router)
app.include_router(v30_router)
app.include_router(v32_router)
app.include_router(v33_router)
app.include_router(v34_router)
app.include_router(v35_router)
app.include_router(v36_router)
try:
    from .api_v31 import router as v31_router
    app.include_router(v31_router)
except Exception:
    pass

@app.on_event("startup")
def startup():
    policy()
    db.init_db()

@app.get("/")
def root(): return {"name":"AI Trading","mode":"PAPER","live_enabled":False,"version":"36.0"}
