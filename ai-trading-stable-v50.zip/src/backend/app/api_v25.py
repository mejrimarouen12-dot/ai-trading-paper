from fastapi import APIRouter
from .execution_v24 import OrderState
from .execution_service_v24 import ExecutionServiceV24
router=APIRouter(prefix='/v25',tags=['v25']); service=ExecutionServiceV24()
@router.post('/recovery/check')
def recovery_check(): return service.reconciliation()
@router.post('/recovery/reload')
def recovery_reload(): return service.recover()
@router.get('/recovery/status')
def recovery_status(): return {'ok':True,'inflight_orders':[service.machine.snapshot(k) for k,v in service.machine.states.items() if v in (OrderState.SUBMITTED,OrderState.PARTIALLY_FILLED,OrderState.CANCEL_PENDING)]}
