class DecisionValidatorV23:
    ALLOWED={'BUY','SELL','HOLD'}
    def validate(self,d):
        if not isinstance(d,dict): return False,'INVALID_OBJECT'
        if d.get('decision') not in self.ALLOWED: return False,'INVALID_DECISION'
        if d['decision']=='HOLD': return True,'OK'
        try:
            e=float(d['entry']); s=float(d['stop_loss']); t=float(d['take_profit']); c=float(d['confidence'])
        except (KeyError,TypeError,ValueError): return False,'MISSING_NUMERIC_FIELDS'
        if not 0<=c<=1: return False,'INVALID_CONFIDENCE'
        if e<=0 or s<=0 or t<=0: return False,'INVALID_PRICES'
        risk=abs(e-s); reward=abs(t-e)
        if risk<=0 or reward/risk<1.8: return False,'BAD_RR'
        if not d.get('thesis') or not d.get('invalidation_condition'): return False,'MISSING_THESIS_INVALIDATION'
        return True,'OK'
