from fastapi import APIRouter
from .security_v30 import policy, validate_numeric_env, redact

router = APIRouter(prefix='/v30', tags=['v30'])

@router.get('/security')
def security():
    p = policy()
    return {'mode': p.mode, 'live_enabled': p.live_enabled, 'require_auth': p.require_auth, 'paper_only': True}

@router.get('/config-check')
def config_check():
    policy()
    values = validate_numeric_env()
    return {'ok': True, 'paper_only': True, 'validated': sorted(values.keys())}

@router.post('/redact')
def redact_payload(payload: dict):
    return redact(payload)
