import math
from dataclasses import dataclass
from typing import List

@dataclass
class Candle:
    ts: int
    open: float
    high: float
    low: float
    close: float
    volume: float

@dataclass
class Snapshot:
    symbol: str
    price: float
    ema20: float
    ema50: float
    rsi: float
    atr: float
    volume_ratio: float
    regime: str
    quality: bool

def ema(values: List[float], period: int) -> float:
    if not values: return 0.0
    k = 2 / (period + 1)
    e = values[0]
    for v in values[1:]: e = v * k + e * (1-k)
    return e

def rsi(values: List[float], period: int = 14) -> float:
    if len(values) < period + 1: return 50.0
    gains=[]; losses=[]
    for a,b in zip(values[-period-1:-1], values[-period:]):
        d=b-a; gains.append(max(d,0)); losses.append(max(-d,0))
    ag=sum(gains)/period; al=sum(losses)/period
    return 100.0 if al == 0 else 100 - 100/(1+ag/al)

def atr(candles: List[Candle], period: int = 14) -> float:
    if len(candles) < 2: return 0.0
    trs=[]
    for prev,c in zip(candles[-period-1:-1], candles[-period:]):
        trs.append(max(c.high-c.low, abs(c.high-prev.close), abs(c.low-prev.close)))
    return sum(trs)/len(trs) if trs else 0.0

class MarketEngine:
    def __init__(self): self.t=0
    def candles(self, symbol: str, n: int = 250) -> List[Candle]:
        base={"BTC/USDT":60000,"ETH/USDT":3000,"SOL/USDT":140}[symbol]
        out=[]; prev=base
        for i in range(n):
            x=i+1
            drift=0.00035*math.sin(x/17)+0.00022*math.sin(x/43)+0.00010*math.sin(x/7)
            shock=0.0025*math.sin(x/5.3)
            close=prev*(1+drift+shock)
            op=prev
            hi=max(op,close)*(1+0.0015+0.0008*abs(math.sin(x/9)))
            lo=min(op,close)*(1-0.0015-0.0008*abs(math.cos(x/11)))
            vol=1000*(1+0.35*math.sin(x/13)+0.15*math.cos(x/31))
            out.append(Candle(x,op,hi,lo,close,max(vol,1)))
            prev=close
        return out
    def snapshot_from_candles(self, symbol, candles):
        closes=[c.close for c in candles]
        price=closes[-1]; e20=ema(closes[-20:],20); e50=ema(closes[-50:],50)
        rr=rsi(closes); aa=atr(candles); vr=candles[-1].volume/(sum(c.volume for c in candles[-20:])/min(20,len(candles)))
        regime='TREND_UP' if e20>e50 and rr>52 else 'TREND_DOWN' if e20<e50 and rr<48 else 'RANGE'
        quality=len(candles)>=60 and aa>0 and price>0
        return Snapshot(symbol,price,e20,e50,rr,aa,vr,regime,quality)
    def snapshot(self,symbol):
        self.t += 1
        c=self.candles(symbol,250+self.t%20)
        return self.snapshot_from_candles(symbol,c)
