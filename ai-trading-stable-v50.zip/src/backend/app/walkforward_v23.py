from dataclasses import dataclass
from typing import Callable, List

@dataclass
class Window:
    train_start:int; train_end:int; test_start:int; test_end:int

def windows(n, train=100, test=50, step=50):
    out=[]; i=0
    while i+train+test<=n:
        out.append(Window(i,i+train,i+train,i+train+test)); i+=step
    return out

def run(candles, evaluator:Callable, train=100, test=50, step=50):
    result=[]
    for w in windows(len(candles),train,test,step):
        # evaluator receives only the test segment; no future/test data enters training slice.
        result.append({'window':w.__dict__,'train_size':w.train_end-w.train_start,'test_size':w.test_end-w.test_start,'result':evaluator(candles[w.test_start:w.test_end])})
    return result
