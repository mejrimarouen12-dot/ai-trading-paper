from dataclasses import dataclass
from enum import Enum
from typing import Dict, Optional

class OrderState(str, Enum):
    CREATED='CREATED'
    VALIDATED='VALIDATED'
    SUBMITTED='SUBMITTED'
    PARTIALLY_FILLED='PARTIALLY_FILLED'
    FILLED='FILLED'
    CANCEL_PENDING='CANCEL_PENDING'
    CANCELLED='CANCELLED'
    REJECTED='REJECTED'
    FAILED='FAILED'

_ALLOWED={
    OrderState.CREATED:{OrderState.VALIDATED,OrderState.REJECTED},
    OrderState.VALIDATED:{OrderState.SUBMITTED,OrderState.REJECTED},
    OrderState.SUBMITTED:{OrderState.PARTIALLY_FILLED,OrderState.FILLED,OrderState.CANCEL_PENDING,OrderState.FAILED},
    OrderState.PARTIALLY_FILLED:{OrderState.FILLED,OrderState.CANCEL_PENDING,OrderState.FAILED},
    OrderState.CANCEL_PENDING:{OrderState.CANCELLED,OrderState.FILLED,OrderState.FAILED},
    OrderState.FILLED:set(), OrderState.CANCELLED:set(), OrderState.REJECTED:set(), OrderState.FAILED:set(),
}

@dataclass(frozen=True)
class Order:
    order_id: str
    symbol: str
    side: str
    quantity: float
    price: float

class OrderStateMachineV24:
    def __init__(self):
        self.states: Dict[str,OrderState]={}
        self.orders: Dict[str,Order]={}
        self.filled: Dict[str,float]={}

    def create(self, order: Order):
        if order.order_id in self.orders:
            return False,'DUPLICATE_ORDER_ID'
        if order.side not in ('BUY','SELL') or order.quantity<=0 or order.price<=0 or not order.symbol:
            return False,'INVALID_ORDER'
        self.orders[order.order_id]=order
        self.states[order.order_id]=OrderState.CREATED
        self.filled[order.order_id]=0.0
        return True,'CREATED'

    def transition(self, order_id:str, target:OrderState):
        if order_id not in self.states: return False,'UNKNOWN_ORDER'
        current=self.states[order_id]
        if target not in _ALLOWED[current]: return False,f'INVALID_TRANSITION:{current}->{target}'
        self.states[order_id]=target
        return True,target.value

    def fill(self, order_id:str, quantity:float):
        if order_id not in self.orders: return False,'UNKNOWN_ORDER'
        if quantity<=0: return False,'INVALID_FILL'
        state=self.states[order_id]
        if state not in (OrderState.SUBMITTED,OrderState.PARTIALLY_FILLED,OrderState.CANCEL_PENDING):
            return False,'FILL_NOT_ALLOWED'
        total=self.filled[order_id]+quantity
        if total>self.orders[order_id].quantity+1e-12: return False,'OVERFILL'
        self.filled[order_id]=total
        target=OrderState.FILLED if abs(total-self.orders[order_id].quantity)<1e-12 else OrderState.PARTIALLY_FILLED
        self.states[order_id]=target
        return True,target.value

    def snapshot(self, order_id:str)->Optional[dict]:
        if order_id not in self.orders: return None
        o=self.orders[order_id]
        return {'order_id':o.order_id,'symbol':o.symbol,'side':o.side,'quantity':o.quantity,'price':o.price,'state':self.states[order_id].value,'filled_quantity':self.filled[order_id]}
