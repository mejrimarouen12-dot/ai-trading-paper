from fastapi import APIRouter
from .execution_service_v24 import ExecutionServiceV24
from .execution_v24 import Order, OrderState

router=APIRouter(prefix='/v24',tags=['v24'])
service=ExecutionServiceV24()

@router.post('/orders')
def create(order:dict):
    o=Order(order_id=str(order['order_id']),symbol=str(order['symbol']),side=str(order['side']),quantity=float(order['quantity']),price=float(order['price']))
    ok,msg=service.create_order(o); return {'ok':ok,'message':msg,'order':service.machine.snapshot(o.order_id)}

@router.post('/orders/{order_id}/transition')
def transition(order_id:str,state:str):
    try: target=OrderState(state)
    except ValueError: return {'ok':False,'message':'INVALID_STATE'}
    ok,msg=service.transition(order_id,target); return {'ok':ok,'message':msg,'order':service.machine.snapshot(order_id)}

@router.post('/orders/{order_id}/fill')
def fill(order_id:str, quantity:float):
    ok,msg=service.fill(order_id,quantity); return {'ok':ok,'message':msg,'order':service.machine.snapshot(order_id)}

@router.get('/orders/{order_id}')
def get_order(order_id:str): return service.machine.snapshot(order_id) or {'error':'UNKNOWN_ORDER'}

@router.get('/audit')
def audit(): return {'valid':service.audit.verify(),'events':service.audit.export()}
