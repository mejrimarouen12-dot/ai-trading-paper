from __future__ import annotations
import csv, json, urllib.parse, urllib.request
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

@dataclass(frozen=True)
class Candle:
    ts: int
    open: float
    high: float
    low: float
    close: float
    volume: float

def fetch_binance_klines(symbol: str, interval: str = "5m", limit: int = 500, base_url: str = "https://api.binance.com") -> list[Candle]:
    # Public market-data endpoint; no account/API key is required.
    params = urllib.parse.urlencode({"symbol": symbol.replace("/", ""), "interval": interval, "limit": min(limit, 1000)})
    url = f"{base_url.rstrip('/')}/api/v3/klines?{params}"
    req = urllib.request.Request(url, headers={"User-Agent": "AI-Trading-Paper/3.0"})
    with urllib.request.urlopen(req, timeout=10) as r:
        rows = json.loads(r.read().decode())
    return [Candle(int(x[0]), float(x[1]), float(x[2]), float(x[3]), float(x[4]), float(x[5])) for x in rows]

def load_csv(path: str | Path) -> list[Candle]:
    out=[]
    with open(path, newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            ts=r.get("timestamp") or r.get("ts") or r.get("time")
            if not ts: continue
            try: ts=int(float(ts))
            except ValueError: ts=int(datetime.fromisoformat(ts.replace("Z","+00:00")).timestamp()*1000)
            out.append(Candle(ts,float(r["open"]),float(r["high"]),float(r["low"]),float(r["close"]),float(r.get("volume",0))))
    return sorted(out,key=lambda x:x.ts)

def save_csv(candles: list[Candle], path: str | Path):
    with open(path,"w",newline="",encoding="utf-8") as f:
        w=csv.writer(f); w.writerow(["timestamp","open","high","low","close","volume"])
        for c in candles: w.writerow([c.ts,c.open,c.high,c.low,c.close,c.volume])
