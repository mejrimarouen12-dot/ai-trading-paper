from dataclasses import dataclass, asdict
from typing import List, Dict
from .market import Candle, MarketEngine
from .expert import decide
from .backtest import run

@dataclass
class StrategySpec:
    name: str
    version: str
    description: str
    risk_per_trade: float = 0.01

REGISTRY = [
    StrategySpec('trend_momentum','1.0','EMA alignment + RSI + volume confirmation'),
    StrategySpec('conservative_trend','1.0','Same trend engine with stricter momentum threshold'),
]

def _decision(spec: StrategySpec, snapshot):
    d = decide(snapshot)
    if spec.name == 'conservative_trend' and d.get('decision') != 'HOLD':
        if snapshot.regime == 'TREND_UP' and snapshot.rsi < 60: return {'decision':'HOLD','reason':'Conservative filter'}
        if snapshot.regime == 'TREND_DOWN' and snapshot.rsi > 40: return {'decision':'HOLD','reason':'Conservative filter'}
    return d

def evaluate(spec: StrategySpec, candles: List[Candle], starting=10000):
    if len(candles) < 100: return {'error':'not_enough_candles'}
    cash=starting; position=None; peak=starting; max_dd=0; trades=[]
    fee=.0004
    m=MarketEngine()
    for i in range(60,len(candles)):
        window=candles[:i+1]; s=m.snapshot_from_candles('TEST/USDT',window); d=_decision(spec,s); px=s.price
        if position:
            side=position['side']; stop=position['stop']; target=position['target']; exit_px=None
            if side=='BUY':
                if window[-1].low<=stop: exit_px=stop
                elif window[-1].high>=target: exit_px=target
            else:
                if window[-1].high>=stop: exit_px=stop
                elif window[-1].low<=target: exit_px=target
            if exit_px is not None:
                q=position['qty']; gross=(exit_px-position['entry'])*q if side=='BUY' else (position['entry']-exit_px)*q
                cash += gross-(position['entry']+exit_px)*q*fee; trades.append(cash-position['cash_before']); position=None
        if position is None and d.get('decision') in ('BUY','SELL') and d.get('entry'):
            entry=float(d['entry']); stop=float(d['stop_loss']); target=float(d['take_profit']); risk=abs(entry-stop)
            if risk>0: position={'side':d['decision'],'entry':entry,'stop':stop,'target':target,'qty':(cash*.01)/risk,'cash_before':cash}
        equity=cash
        if position:
            q=position['qty']; equity += ((px-position['entry'])*q if position['side']=='BUY' else (position['entry']-px)*q)
        peak=max(peak,equity); max_dd=max(max_dd,(peak-equity)/peak if peak else 0)
    return {'strategy':spec.name,'version':spec.version,'ending_balance':round(cash,2),'net_pnl':round(cash-starting,2),'return_pct':round((cash/starting-1)*100,2),'trades':len(trades),'win_rate_pct':round(sum(x>0 for x in trades)/len(trades)*100,2) if trades else 0,'max_drawdown_pct':round(max_dd*100,2)}

def compare(candles, starting=10000):
    results=[evaluate(s,candles,starting) for s in REGISTRY]
    # Selection is descriptive only; governance requires manual promotion.
    return {'strategies':[asdict(s) for s in REGISTRY],'results':results,'promotion':'MANUAL_ONLY'}

def regime_slices(candles):
    m=MarketEngine(); buckets={'TREND_UP':0,'TREND_DOWN':0,'RANGE':0}
    for i in range(60,len(candles)):
        buckets[m.snapshot_from_candles('TEST/USDT',candles[:i+1]).regime]+=1
    return buckets

def stress_test(candles):
    base=compare(candles)
    if len(candles)<120: return {'base':base,'stress':[]}
    scenarios={'full':candles,'first_half':candles[:len(candles)//2],'second_half':candles[len(candles)//2:]}
    return {'base':base,'stress':[{'scenario':k,'results':compare(v)['results']} for k,v in scenarios.items()]}
