import os
import re
from dataclasses import dataclass

SECRET_RE = re.compile(r"(?i)(api[_-]?key|secret|token|password|authorization)\s*[:=]\s*[^\s,;]+")

@dataclass(frozen=True)
class SecurityPolicyV30:
    mode: str
    live_enabled: bool
    allow_docs: bool
    require_auth: bool


def policy() -> SecurityPolicyV30:
    mode = os.getenv("MODE", "PAPER").upper()
    live = os.getenv("LIVE_TRADING", "false").lower() in {"1", "true", "yes", "on"}
    # This release intentionally cannot enable live trading.
    if mode != "PAPER" or live:
        raise RuntimeError("V30 is PAPER-only; LIVE_TRADING cannot be enabled.")
    return SecurityPolicyV30(mode="PAPER", live_enabled=False,
                             allow_docs=os.getenv("ALLOW_API_DOCS", "true").lower() not in {"0", "false", "no"},
                             require_auth=os.getenv("REQUIRE_API_AUTH", "false").lower() in {"1", "true", "yes", "on"})


def validate_numeric_env() -> dict:
    checks = {
        "PAPER_BALANCE": (float, lambda x: x > 0),
        "RISK_PER_TRADE": (float, lambda x: 0 < x <= 0.02),
        "MAX_DAILY_LOSS": (float, lambda x: 0 < x <= 0.10),
        "MAX_OPEN_POSITIONS": (int, lambda x: 1 <= x <= 20),
    }
    out = {}
    for key, (cast, predicate) in checks.items():
        raw = os.getenv(key)
        if raw is None:
            continue
        try:
            value = cast(raw)
        except ValueError as exc:
            raise RuntimeError(f"Invalid {key}") from exc
        if not predicate(value):
            raise RuntimeError(f"Unsafe {key} value")
        out[key] = value
    return out


def redact(value):
    if isinstance(value, dict):
        return {k: ("[REDACTED]" if re.search(r"(?i)(key|secret|token|password|authorization)", str(k)) else redact(v)) for k, v in value.items()}
    if isinstance(value, list):
        return [redact(v) for v in value]
    if isinstance(value, str):
        return SECRET_RE.sub(lambda m: m.group(1) + "=[REDACTED]", value)
    return value
