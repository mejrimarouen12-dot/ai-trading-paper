from dataclasses import dataclass, asdict
from typing import Dict, List

@dataclass
class Exposure:
    symbol: str
    side: str
    notional: float
    weight: float

@dataclass
class PortfolioRisk:
    gross_exposure: float
    net_exposure: float
    correlated_exposure: float
    risk_budget_used: float
    approved: bool
    reasons: List[str]

class PortfolioIntelligenceV23:
    DEFAULT_CORR = {
        ('BTC/USDT','ETH/USDT'): 0.85, ('ETH/USDT','BTC/USDT'): 0.85,
        ('BTC/USDT','SOL/USDT'): 0.75, ('SOL/USDT','BTC/USDT'): 0.75,
        ('ETH/USDT','SOL/USDT'): 0.80, ('SOL/USDT','ETH/USDT'): 0.80,
    }
    def __init__(self, max_gross_weight=.60, max_correlated_weight=.45, risk_budget=.02):
        self.max_gross_weight=max_gross_weight
        self.max_correlated_weight=max_correlated_weight
        self.risk_budget=risk_budget
    def assess(self, equity: float, exposures: List[Exposure], proposed: Exposure|None=None):
        items=list(exposures)+([proposed] if proposed else [])
        if equity<=0: return PortfolioRisk(0,0,0,1,False,['INVALID_EQUITY'])
        gross=sum(abs(x.notional) for x in items)/equity
        net=sum(x.notional for x in items)/equity
        corr=0.0
        for i,a in enumerate(items):
            for b in items[i+1:]:
                c=self.DEFAULT_CORR.get((a.symbol,b.symbol),0.0)
                corr += min(abs(a.notional),abs(b.notional))*c/equity
        proposed_risk=abs(proposed.notional)/equity if proposed else 0
        reasons=[]
        if gross>self.max_gross_weight: reasons.append('GROSS_EXPOSURE_LIMIT')
        if corr>self.max_correlated_weight: reasons.append('CORRELATED_EXPOSURE_LIMIT')
        if proposed_risk>self.risk_budget: reasons.append('RISK_BUDGET_LIMIT')
        return PortfolioRisk(gross,net,corr,proposed_risk,self._approved(gross,corr,proposed_risk),reasons)
    def _approved(self,g,c,r): return g<=self.max_gross_weight and c<=self.max_correlated_weight and r<=self.risk_budget
    def correlation_matrix(self, symbols):
        return {a:{b:(1.0 if a==b else self.DEFAULT_CORR.get((a,b),0.0)) for b in symbols} for a in symbols}
