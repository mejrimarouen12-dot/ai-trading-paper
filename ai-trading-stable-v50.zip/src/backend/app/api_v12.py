from fastapi import APIRouter
from .risk_guard_v12 import RiskGuard
from . import db, config

router=APIRouter(prefix='/v12',tags=['v12-risk'])

@router.get('/risk')
def risk():
    g=RiskGuard()
    return {'mode':'PAPER','live_orders':False,'daily_loss_pct':g.daily_loss_pct(),'daily_loss_limit_pct':config.MAX_DAILY_LOSS,'drawdown_pct':g.drawdown_pct(),'max_drawdown_pct':g.MAX_DRAWDOWN_PCT,'paused':db.state('paused')=='1','safe_mode':db.state('safe_mode')=='1'}

@router.post('/risk/reset-daily')
def reset_daily():
    # Manual reset is limited to the risk-day baseline; it does not clear safe mode or emergency stop.
    import datetime
    db.set_state('risk_day',datetime.datetime.now(datetime.timezone.utc).date().isoformat())
    db.set_state('risk_day_start_equity',str(float(db.state('cash') or 0)))
    return risk()
