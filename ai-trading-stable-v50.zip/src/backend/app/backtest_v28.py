from dataclasses import dataclass, asdict
from statistics import mean
from typing import Callable, List, Dict, Any

@dataclass
class BacktestTrade:
    entry_index: int
    exit_index: int
    side: str
    entry: float
    exit: float
    qty: float
    pnl: float
    fees: float
    reason: str

@dataclass
class BacktestReport:
    symbol: str
    bars: int
    starting_balance: float
    ending_balance: float
    net_pnl: float
    return_pct: float
    trades: int
    wins: int
    losses: int
    win_rate_pct: float
    profit_factor: float | None
    avg_r: float
    max_drawdown_pct: float
    longest_losing_streak: int
    fees: float
    lookahead_safe: bool
    stress: Dict[str, Any]

class AdvancedBacktesterV28:
    """Deterministic candle-by-candle backtester with no future-bar access."""
    def __init__(self, fee_rate=0.001, slippage_bps=2.0, risk_per_trade=0.01):
        self.fee_rate=fee_rate; self.slippage_bps=slippage_bps; self.risk_per_trade=risk_per_trade

    def run(self, candles, signal_fn: Callable[[list], dict], starting=10000.0, symbol='BTC/USDT') -> BacktestReport:
        cash=starting; peak=starting; max_dd=0.0; position=None; trades=[]; fees_total=0.0; loss_streak=0; longest=0
        for i in range(len(candles)):
            history=candles[:i+1]
            # signal_fn receives only candles available at index i
            signal=signal_fn(history) or {}
            bar=candles[i]
            if position:
                side=position['side']; stop=position['stop']; target=position['target']; exit_px=None; reason=None
                if side=='BUY':
                    if bar.low <= stop: exit_px=stop; reason='STOP_LOSS'
                    elif bar.high >= target: exit_px=target; reason='TAKE_PROFIT'
                else:
                    if bar.high >= stop: exit_px=stop; reason='STOP_LOSS'
                    elif bar.low <= target: exit_px=target; reason='TAKE_PROFIT'
                if exit_px is not None:
                    exit_px=self._slip(exit_px, side, closing=True)
                    qty=position['qty']; gross=(exit_px-position['entry'])*qty if side=='BUY' else (position['entry']-exit_px)*qty
                    fee=(position['entry']+exit_px)*qty*self.fee_rate; pnl=gross-fee; cash+=pnl; fees_total+=fee
                    r=abs(position['entry']-position['stop'])*qty
                    trades.append(BacktestTrade(position['entry_index'],i,side,position['entry'],exit_px,qty,pnl,fee,reason))
                    if pnl>0: loss_streak=0
                    else: loss_streak+=1; longest=max(longest,loss_streak)
                    position=None
            if position is None and signal.get('decision') in ('BUY','SELL'):
                entry=float(signal.get('entry', bar.close)); stop=float(signal.get('stop_loss',0)); target=float(signal.get('take_profit',0))
                risk=abs(entry-stop)
                if risk>0 and target>0:
                    entry=self._slip(entry, signal['decision'], closing=False)
                    qty=(cash*self.risk_per_trade)/risk
                    position={'side':signal['decision'],'entry':entry,'stop':stop,'target':target,'qty':qty,'entry_index':i}
                    # conservative fee reserved at close accounting rather than cash deduction
            equity=cash
            if position:
                qty=position['qty']; equity += ((bar.close-position['entry'])*qty if position['side']=='BUY' else (position['entry']-bar.close)*qty)
            peak=max(peak,equity); max_dd=max(max_dd,(peak-equity)/peak if peak else 0.0)
        if position:
            bar=candles[-1]; exit_px=self._slip(bar.close,position['side'],closing=True); qty=position['qty']
            gross=(exit_px-position['entry'])*qty if position['side']=='BUY' else (position['entry']-exit_px)*qty
            fee=(position['entry']+exit_px)*qty*self.fee_rate; pnl=gross-fee; cash+=pnl; fees_total+=fee
            trades.append(BacktestTrade(position['entry_index'],len(candles)-1,position['side'],position['entry'],exit_px,qty,pnl,fee,'END_OF_TEST'))
            if pnl>0: loss_streak=0
            else: loss_streak+=1; longest=max(longest,loss_streak)
        wins=[t for t in trades if t.pnl>0]; losses=[t for t in trades if t.pnl<0]
        gp=sum(t.pnl for t in wins); gl=-sum(t.pnl for t in losses)
        rs=[]
        for t in trades:
            # R is normalized by entry risk reconstructed from trade magnitude only when possible.
            rs.append(t.pnl / max(abs(t.entry-t.exit)*t.qty, 1e-12))
        return BacktestReport(symbol,len(candles),starting,round(cash,2),round(cash-starting,2),round((cash/starting-1)*100,2),len(trades),len(wins),len(losses),round(len(wins)/len(trades)*100,2) if trades else 0,round(gp/gl,2) if gl else None,round(mean(rs),4) if rs else 0,round(max_dd*100,2),longest,round(fees_total,4),True,{'tested':False})

    def _slip(self, price, side, closing=False):
        bps=self.slippage_bps/10000.0
        if side=='BUY': return price*(1+bps if not closing else 1-bps)
        return price*(1-bps if not closing else 1+bps)

    def stress_suite(self, candles, signal_fn, starting=10000.0, symbol='BTC/USDT'):
        cases={
            'base': candles,
            'high_volatility': self._scale_ranges(candles,2.5),
            'low_volatility': self._scale_ranges(candles,0.35),
            'downside_shock': self._shock(candles,-0.08),
            'upside_shock': self._shock(candles,0.08),
        }
        out={}
        for name,cs in cases.items():
            r=self.run(cs,signal_fn,starting,symbol)
            out[name]=asdict(r)
        return out

    @staticmethod
    def _scale_ranges(cs,factor):
        if not cs: return []
        out=[]
        for c in cs:
            mid=(c.open+c.close)/2; half=(c.high-c.low)*factor/2
            from .data import Candle
            out.append(Candle(c.ts,mid-(mid-c.open),mid+half,mid-half,mid+(c.close-mid),c.volume))
        return out
    @staticmethod
    def _shock(cs,pct):
        from .data import Candle
        if not cs: return []
        out=[]
        for i,c in enumerate(cs):
            mult=1+pct if i==len(cs)//2 else 1
            out.append(Candle(c.ts,c.open*mult,c.high*mult,c.low*mult,c.close*mult,c.volume))
        return out
