from fastapi import APIRouter
from . import db
from .health import snapshot

router=APIRouter(prefix='/v6',tags=['v6'])

@router.get('/health')
def health(): return snapshot()

@router.get('/events')
def events(limit:int=50):
    c=db.conn(); rows=c.execute('SELECT * FROM events ORDER BY id DESC LIMIT ?',(max(1,min(limit,500)),)).fetchall(); c.close()
    return [dict(r) for r in rows]

@router.get('/system')
def system():
    keys=['paused','safe_mode','emergency_stop','cash','heartbeat_at','worker_consecutive_errors']
    return {k:db.state(k) for k in keys}

@router.post('/clear-safe-mode')
def clear_safe_mode():
    db.set_state('safe_mode','0'); db.set_state('worker_consecutive_errors','0'); db.event('INFO','SAFE_MODE_CLEARED','Safe mode cleared manually')
    return {'ok':True,'safe_mode':False}
