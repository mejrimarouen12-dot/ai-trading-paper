from fastapi import APIRouter
from .watchdog_v35 import PaperWatchdogV35

router = APIRouter(prefix="/v35", tags=["v35-paper-watchdog"])
_watchdog = PaperWatchdogV35()

@router.get("/watchdog")
def watchdog():
    return _watchdog.inspect().__dict__

@router.post("/watchdog/enforce")
def enforce():
    return _watchdog.enforce()
