from fastapi import APIRouter
from .release_v33 import ReleasePreflight
router = APIRouter(prefix="/v33", tags=["v33"])

@router.get("/preflight")
def preflight():
    checks = ReleasePreflight.run()
    return {"version": ReleasePreflight.VERSION, "ready": all(c.ok for c in checks), "checks": [c.__dict__ for c in checks]}

@router.get("/manifest")
def manifest():
    return ReleasePreflight.manifest()
