from fastapi import APIRouter, HTTPException
from .data import load_csv
from .strategy_lab import REGISTRY, compare, regime_slices, stress_test
router=APIRouter(prefix='/v5')

@router.get('/strategies')
def strategies():
    return {'strategies':[s.__dict__ for s in REGISTRY],'promotion_policy':'MANUAL_ONLY'}

@router.post('/lab/compare')
def lab_compare(path:str, starting:float=10000):
    try: c=load_csv(path)
    except Exception as e: raise HTTPException(400,str(e))
    return compare(c,starting)

@router.post('/lab/regimes')
def lab_regimes(path:str):
    try: c=load_csv(path)
    except Exception as e: raise HTTPException(400,str(e))
    return {'regimes':regime_slices(c)}

@router.post('/lab/stress')
def lab_stress(path:str, starting:float=10000):
    try: c=load_csv(path)
    except Exception as e: raise HTTPException(400,str(e))
    return stress_test(c)
