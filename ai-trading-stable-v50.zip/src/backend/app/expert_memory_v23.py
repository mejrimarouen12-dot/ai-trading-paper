from dataclasses import dataclass, asdict
from typing import List, Dict

@dataclass
class TradeMemory:
    decision_id: str
    symbol: str
    decision: str
    regime: str
    thesis: str
    invalidation: str
    outcome: str='OPEN'
    pnl: float=0.0
    lesson: str=''

class ExpertMemoryV23:
    def __init__(self): self.records=[]
    def record(self, **kwargs):
        m=TradeMemory(**kwargs); self.records.append(m); return m
    def close(self, decision_id, pnl, outcome, lesson=''):
        for m in self.records:
            if m.decision_id==decision_id:
                m.pnl=float(pnl); m.outcome=outcome; m.lesson=lesson; return m
        raise KeyError(decision_id)
    def lessons(self):
        return [asdict(x) for x in self.records if x.lesson]
    def review(self):
        closed=[x for x in self.records if x.outcome!='OPEN']
        return {'count':len(closed),'wins':sum(x.pnl>0 for x in closed),'losses':sum(x.pnl<0 for x in closed),'net_pnl':sum(x.pnl for x in closed),'lessons':self.lessons()}
