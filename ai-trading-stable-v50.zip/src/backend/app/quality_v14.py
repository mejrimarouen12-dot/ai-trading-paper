from dataclasses import dataclass
from datetime import datetime, timezone
from . import db

@dataclass
class QualityResult:
    approved: bool
    score: float
    reason: str
    factors: dict

class SetupQualityEngine:
    """Deterministic trade-quality gate. It never opens orders and only filters signals."""
    MIN_SCORE = 0.70
    DUPLICATE_WINDOW_MIN = 30

    def _recent_duplicate(self, symbol, decision):
        c=db.conn()
        row=c.execute("SELECT decision, created_at FROM decisions WHERE symbol=? ORDER BY id DESC LIMIT 1", (symbol,)).fetchone()
        c.close()
        if not row or row['decision'] != decision:
            return False
        try:
            ts=datetime.fromisoformat(str(row['created_at']).replace('Z','+00:00'))
            if ts.tzinfo is None: ts=ts.replace(tzinfo=timezone.utc)
            age=(datetime.now(timezone.utc)-ts).total_seconds()/60
            return age < self.DUPLICATE_WINDOW_MIN
        except Exception:
            return False

    def evaluate(self, snapshot, decision):
        action=decision.get('decision')
        if action not in ('BUY','SELL'):
            return QualityResult(False, 0.0, 'No executable setup', {})
        if not snapshot.quality or snapshot.atr <= 0:
            return QualityResult(False, 0.0, 'Market quality gate failed', {'market_quality':0.0})

        trend = 1.0 if ((action=='BUY' and snapshot.ema20 > snapshot.ema50) or
                         (action=='SELL' and snapshot.ema20 < snapshot.ema50)) else 0.0
        momentum = min(1.0, max(0.0, (snapshot.rsi-50)/20)) if action=='BUY' else min(1.0, max(0.0, (50-snapshot.rsi)/20))
        volume = min(1.0, max(0.0, snapshot.volume_ratio/1.25))
        volatility = 1.0 if 0.0005 <= snapshot.atr/max(snapshot.price,1e-9) <= 0.04 else 0.4
        rr=0.0
        try:
            rr=abs(float(decision['take_profit'])-float(decision['entry']))/abs(float(decision['entry'])-float(decision['stop_loss']))
        except Exception:
            pass
        rr_factor=min(1.0, rr/2.5) if rr>0 else 0.0
        contrarian=0.8 if str(decision.get('contrarian_risk','')).strip() else 0.3
        duplicate=0.0 if self._recent_duplicate(snapshot.symbol, action) else 1.0

        if rr < 1.8:
            return QualityResult(False, round(0.22*trend + 0.18*momentum + 0.12*volume + 0.10*volatility + 0.10*contrarian + 0.10*duplicate,4), 'Risk/reward below quality minimum', {'risk_reward':rr})

        factors={'trend':trend,'momentum':momentum,'volume':volume,'volatility':volatility,'risk_reward':rr_factor,'contrarian':contrarian,'freshness':duplicate}
        score=(0.22*trend + 0.18*momentum + 0.12*volume + 0.10*volatility + 0.18*rr_factor + 0.10*contrarian + 0.10*duplicate)
        score=round(score,4)
        if duplicate == 0.0:
            reason='Duplicate signal inside freshness window'
        elif score < self.MIN_SCORE:
            reason=f'Setup quality below threshold ({score:.2f} < {self.MIN_SCORE:.2f})'
        else:
            reason='Setup quality approved'
        return QualityResult(score >= self.MIN_SCORE, score, reason, factors)

def record_quality(symbol, decision_id, result):
    c=db.conn()
    c.execute('''CREATE TABLE IF NOT EXISTS setup_quality(
      id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT, decision_id INTEGER,
      score REAL, approved INTEGER, reason TEXT, factors_json TEXT, created_at TEXT)''')
    import json
    c.execute('INSERT INTO setup_quality(symbol,decision_id,score,approved,reason,factors_json,created_at) VALUES(?,?,?,?,?,?,?)',
              (symbol,decision_id,result.score,int(result.approved),result.reason,json.dumps(result.factors,sort_keys=True),db.now()))
    c.commit(); c.close()
