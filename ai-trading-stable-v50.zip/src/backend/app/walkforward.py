from __future__ import annotations
from dataclasses import dataclass
from .data import Candle
from .indicators import ema,rsi,atr

@dataclass
class WFResult:
    folds:int; trades:int; wins:int; pnl:float; return_pct:float; max_drawdown_pct:float

def signal(history:list[Candle]):
    closes=[c.close for c in history]; e20=ema(closes,20); e50=ema(closes,50); rv=rsi(closes); av=atr(history)
    if None in (e20,e50,rv,av): return "HOLD",None,None
    p=closes[-1]
    if p>e20>e50 and 50<rv<72: return "BUY",p-av*1.5,p+av*3
    if p<e20<e50 and 28<rv<50: return "SELL",p+av*1.5,p-av*3
    return "HOLD",None,None

def run_walk_forward(candles:list[Candle], train:int=250, test:int=100)->WFResult:
    equity=10000.; peak=equity; maxdd=0.; trades=wins=0; pnl=0.; folds=0
    i=train
    while i < len(candles):
        end=min(i+test,len(candles)); folds+=1; pos=None
        for j in range(i,end):
            hist=candles[:j+1]; dec,sl,tp=signal(hist); price=candles[j].close
            if pos is None and dec in ("BUY","SELL"):
                pos={"side":dec,"entry":price,"sl":sl,"tp":tp}
            elif pos:
                hit=(pos["side"]=="BUY" and (price<=pos["sl"] or price>=pos["tp"])) or (pos["side"]=="SELL" and (price>=pos["sl"] or price<=pos["tp"]))
                if hit:
                    r=(price-pos["entry"])*(1 if pos["side"]=="BUY" else -1); pnl+=r; equity+=r; trades+=1; wins+=r>0; pos=None
                    peak=max(peak,equity); maxdd=max(maxdd,(peak-equity)/peak*100)
        i=end
    return WFResult(folds,trades,wins,pnl,(equity/10000-1)*100,maxdd)
