from dataclasses import dataclass
from enum import Enum

class Fault(str, Enum):
    DELAYED_DATA="delayed_data"
    MISSING_DATA="missing_data"
    INVALID_AI="invalid_ai"
    DB_FAILURE="db_failure"
    EXECUTION_FAILURE="execution_failure"
    DUPLICATE_ORDER="duplicate_order"
    PRICE_JUMP="price_jump"
    NETWORK_FAILURE="network_failure"

@dataclass
class ChaosResult:
    fault: str
    safe: bool
    action: str

class ChaosLab:
    EXPECTED = {
        Fault.DELAYED_DATA:(True,"NO_NEW_TRADE"), Fault.MISSING_DATA:(True,"NO_NEW_TRADE"),
        Fault.INVALID_AI:(True,"NO_NEW_TRADE"), Fault.DB_FAILURE:(True,"SAFE_MODE"),
        Fault.EXECUTION_FAILURE:(True,"SAFE_MODE"), Fault.DUPLICATE_ORDER:(True,"REJECT_DUPLICATE"),
        Fault.PRICE_JUMP:(True,"RECHECK_RISK"), Fault.NETWORK_FAILURE:(True,"SAFE_MODE")}
    def run(self, fault: Fault) -> ChaosResult:
        safe, action=self.EXPECTED[fault]
        return ChaosResult(fault.value,safe,action)
    def run_all(self):
        return [self.run(f) for f in Fault]
