from fastapi import APIRouter
from .certification_v31 import PaperCertificationV31

router = APIRouter(prefix='/v31', tags=['v31-certification'])

@router.get('/certification')
def certification():
    return PaperCertificationV31().run()
