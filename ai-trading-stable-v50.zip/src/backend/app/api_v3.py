from fastapi import APIRouter, HTTPException
from .data import fetch_binance_klines, load_csv
from .walkforward import run_walk_forward
from .multitimeframe import consensus
router=APIRouter(prefix="/v3")

@router.get("/market/live")
def live_market(symbol:str="BTC/USDT",interval:str="5m",limit:int=300):
    try:
        c=fetch_binance_klines(symbol,interval,limit)
        return {"symbol":symbol,"interval":interval,"count":len(c),"last":c[-1].__dict__ if c else None}
    except Exception as e: raise HTTPException(502,f"market data unavailable: {e}")

@router.post("/walk-forward")
def walk_forward(path:str,train:int=250,test:int=100):
    try:c=load_csv(path)
    except Exception as e:raise HTTPException(400,str(e))
    if len(c)<train+test:raise HTTPException(400,"not enough candles")
    return run_walk_forward(c,train,test).__dict__

from .intelligence import replay_decision, trade_memory, lessons

@router.get('/intelligence/memory')
def intelligence_memory(limit:int=50):
    return trade_memory(max(1,min(limit,500)))

@router.get('/intelligence/lessons')
def intelligence_lessons(limit:int=50):
    return {'lessons': lessons(max(1,min(limit,500)))}

@router.get('/intelligence/replay/{decision_id}')
def intelligence_replay(decision_id:int):
    result=replay_decision(decision_id)
    return result or {'error':'decision_not_found'}
