from dataclasses import dataclass

@dataclass(frozen=True)
class StrategyPolicy:
    regime: str
    style: str
    min_quality: float
    min_confidence: float
    min_rr: float
    allow_entries: bool
    allowed_actions: tuple
    reason: str

@dataclass(frozen=True)
class AdaptiveResult:
    approved: bool
    action: str
    score: float
    reason: str
    policy: StrategyPolicy

class AdaptiveStrategyEngineV19:
    """Regime-aware strategy policy. It advises only; Risk Guard remains final authority."""
    POLICIES = {
        "TRENDING_UP": StrategyPolicy("TRENDING_UP", "trend-following", .70, .65, 2.0, True, ("BUY",), "Uptrend policy: only aligned long setups are eligible"),
        "TRENDING_DOWN": StrategyPolicy("TRENDING_DOWN", "trend-following", .70, .65, 2.0, True, ("SELL",), "Downtrend policy: only aligned short setups are eligible"),
        "RANGING": StrategyPolicy("RANGING", "mean-reversion", .78, .70, 2.0, False, (), "Range policy is defined but entry is disabled by the safety regime gate"),
        "HIGH_VOLATILITY": StrategyPolicy("HIGH_VOLATILITY", "defensive", .85, .80, 2.5, False, (), "High-volatility policy: no new entries"),
        "TRANSITION": StrategyPolicy("TRANSITION", "wait-for-confirmation", .82, .75, 2.2, False, (), "Transition policy: wait for regime confirmation"),
        "UNKNOWN": StrategyPolicy("UNKNOWN", "no-trade", 1.0, 1.0, 99.0, False, (), "Unknown regime: no trade"),
    }

    def policy(self, regime: str) -> StrategyPolicy:
        return self.POLICIES.get(regime, self.POLICIES["UNKNOWN"])

    def evaluate(self, regime: str, action: str, quality_score: float, confidence: float, risk_reward: float) -> AdaptiveResult:
        p = self.policy(regime)
        if action not in ("BUY", "SELL"):
            return AdaptiveResult(False, "HOLD", 0.0, "No executable action", p)
        if not p.allow_entries:
            return AdaptiveResult(False, "HOLD", 0.0, p.reason, p)
        if action not in p.allowed_actions:
            return AdaptiveResult(False, "HOLD", 0.0, "Action conflicts with market-regime policy", p)
        checks = {
            "quality": quality_score >= p.min_quality,
            "confidence": confidence >= p.min_confidence,
            "risk_reward": risk_reward >= p.min_rr,
        }
        score = round(sum(checks.values()) / len(checks), 4)
        if not all(checks.values()):
            failed = ", ".join(k for k, ok in checks.items() if not ok)
            return AdaptiveResult(False, "HOLD", score, f"Adaptive policy rejected setup: {failed}", p)
        return AdaptiveResult(True, action, score, p.reason, p)
