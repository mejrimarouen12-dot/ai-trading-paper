from dataclasses import dataclass, asdict
from datetime import datetime, timezone
import time
from . import db, config
from .paper_session import PaperSession
from .operations_v36 import PaperOperationsV36

@dataclass
class RunnerStatus:
    state: str
    cycles: int
    last_cycle_at: str | None
    last_status: str | None
    stop_requested: bool
    live_enabled: bool = False

class PaperRunnerV34:
    VERSION = "34.0"
    LOCK_KEY = "paper_runner_lock"
    STOP_KEY = "paper_runner_stop"
    CYCLES_KEY = "paper_runner_cycles"
    LAST_AT_KEY = "paper_runner_last_at"
    LAST_STATUS_KEY = "paper_runner_last_status"

    def __init__(self, session=None):
        self.session = session or PaperSession()
        self.operations = PaperOperationsV36()

    @staticmethod
    def _int(key):
        try: return int(db.state(key) or 0)
        except (TypeError, ValueError): return 0

    def status(self):
        locked = db.state(self.LOCK_KEY) == "1"
        stop = db.state(self.STOP_KEY) == "1"
        if stop:
            state = "STOP_REQUESTED"
        elif locked:
            state = "RUNNING"
        else:
            state = "IDLE"
        return RunnerStatus(state, self._int(self.CYCLES_KEY), db.state(self.LAST_AT_KEY), db.state(self.LAST_STATUS_KEY), stop)

    def request_stop(self):
        db.set_state(self.STOP_KEY, "1")
        db.event("INFO", "PAPER_RUNNER_STOP_REQUESTED", "stop requested")
        return self.status()

    def clear_stop(self):
        db.set_state(self.STOP_KEY, "0")

    def run_once(self):
        if db.state(self.LOCK_KEY) == "1":
            return {"status": "BUSY", "version": self.VERSION}
        if any(db.state(k) == "1" for k in ("paused", "safe_mode", "emergency_stop")):
            return {"status": "BLOCKED", "version": self.VERSION, "reason": "safety state active"}
        db.set_state(self.LOCK_KEY, "1")
        started_at = datetime.now(timezone.utc).isoformat()
        try:
            report = self.session.run_cycle()
            n = self._int(self.CYCLES_KEY) + 1
            stamp = datetime.now(timezone.utc).isoformat()
            db.set_state(self.CYCLES_KEY, str(n))
            db.set_state(self.LAST_AT_KEY, stamp)
            db.set_state(self.LAST_STATUS_KEY, report.status)
            finished_at = datetime.now(timezone.utc).isoformat()
            self.operations.record_cycle(n, report, started_at, finished_at)
            report_data = asdict(report) if hasattr(report, "__dataclass_fields__") else dict(vars(report))
            return {"status": report.status, "version": self.VERSION, "cycle": n, "report": report_data, "timestamp": stamp}
        finally:
            db.set_state(self.LOCK_KEY, "0")

    def run_bounded(self, cycles=1, interval_seconds=60):
        cycles = max(1, min(int(cycles), 1440))
        interval_seconds = max(0, min(int(interval_seconds), 3600))
        self.clear_stop()
        results = []
        for i in range(cycles):
            if db.state(self.STOP_KEY) == "1":
                break
            results.append(self.run_once())
            if i < cycles - 1 and db.state(self.STOP_KEY) != "1":
                time.sleep(interval_seconds)
        return {"version": self.VERSION, "requested_cycles": cycles, "completed_cycles": len(results), "results": results, "final": asdict(self.status())}
