from fastapi import APIRouter
from .chaos import ChaosLab, Fault
from .integrity import IntegrityEngine

router=APIRouter(prefix="/v7", tags=["v7-integrity"])

@router.get("/chaos")
def chaos():
    return [r.__dict__ for r in ChaosLab().run_all()]

@router.get("/integrity/order")
def validate_order(order_id:str="demo-1",symbol:str="BTC/USDT",side:str="BUY",quantity:float=1,price:float=100):
    issues=IntegrityEngine().validate_order(order_id=order_id,symbol=symbol,side=side,quantity=quantity,price=price)
    return {"ok":not issues,"issues":issues}
