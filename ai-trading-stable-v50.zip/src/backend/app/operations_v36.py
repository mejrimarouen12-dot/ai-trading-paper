from dataclasses import dataclass, asdict
from datetime import datetime, timezone, timedelta
from . import db

@dataclass
class CycleLedgerEntry:
    id: int
    cycle: int
    status: str
    decisions: int
    executed: int
    rejected: int
    closed: int
    started_at: str
    finished_at: str

class PaperOperationsV36:
    VERSION = "36.0"

    def record_cycle(self, cycle, report, started_at, finished_at):
        c = db.conn()
        c.execute(
            "INSERT INTO paper_cycles(cycle,status,decisions,executed,rejected,closed,started_at,finished_at) VALUES(?,?,?,?,?,?,?,?)",
            (cycle, report.status, report.decisions, report.executed, report.rejected, report.closed, started_at, finished_at),
        )
        c.commit(); c.close()

    def history(self, limit=50):
        try: limit = max(1, min(int(limit), 500))
        except (TypeError, ValueError): limit = 50
        c = db.conn()
        rows = c.execute("SELECT id,cycle,status,decisions,executed,rejected,closed,started_at,finished_at FROM paper_cycles ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        c.close()
        return [dict(r) for r in rows]

    def summary(self):
        c = db.conn()
        r = c.execute("SELECT COUNT(*) n, COALESCE(SUM(decisions),0) decisions, COALESCE(SUM(executed),0) executed, COALESCE(SUM(rejected),0) rejected, COALESCE(SUM(closed),0) closed FROM paper_cycles").fetchone()
        c.close()
        return {"version": self.VERSION, "cycles_recorded": r[0], "decisions": r[1], "executed": r[2], "rejected": r[3], "closed": r[4], "live_enabled": False}
