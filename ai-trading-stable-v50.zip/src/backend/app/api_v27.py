from fastapi import APIRouter
from .scanner_v27 import MarketScannerV27
router=APIRouter(prefix='/v27',tags=['v27'])
_scanner=MarketScannerV27()
@router.get('/policy')
def policy():
    return {'mode':'PAPER','live_enabled':False,'min_score':_scanner.min_score,'purpose':'scan_and_rank_only','execution':'disabled'}
@router.get('/health')
def health():
    return {'ok':True,'scanner':'ready','execution':'disabled'}
