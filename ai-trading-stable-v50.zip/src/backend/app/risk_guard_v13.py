from dataclasses import dataclass
from datetime import datetime, timezone
from .risk_guard_v12 import RiskGuard
from . import db, config

@dataclass
class V13Decision:
    approved: bool
    reason: str
    quantity: float = 0.0
    risk_amount: float = 0.0

class AdvancedRiskGuard:
    """V13 supervisory layer: cooldown, trade-frequency and exposure guards over V12."""
    MAX_TRADES_PER_DAY = int(__import__('os').getenv('MAX_TRADES_PER_DAY', '8'))
    LOSS_COOLDOWN_MIN = int(__import__('os').getenv('LOSS_COOLDOWN_MIN', '30'))
    MAX_CONSECUTIVE_LOSSES = int(__import__('os').getenv('MAX_CONSECUTIVE_LOSSES', '3'))

    def _today(self):
        return datetime.now(timezone.utc).date().isoformat()

    def trades_today(self):
        c=db.conn(); row=c.execute("SELECT COUNT(*) n FROM trades WHERE created_at >= ?", (self._today(),)).fetchone(); c.close()
        return int(row['n'] or 0)

    def consecutive_losses(self):
        c=db.conn(); rows=c.execute("SELECT pnl FROM trades ORDER BY id DESC LIMIT 20").fetchall(); c.close()
        n=0
        for r in rows:
            if float(r['pnl'] or 0) < 0: n+=1
            else: break
        return n

    def last_loss_age_minutes(self):
        c=db.conn(); row=c.execute("SELECT created_at FROM trades WHERE pnl < 0 ORDER BY id DESC LIMIT 1").fetchone(); c.close()
        if not row: return None
        try:
            ts=datetime.fromisoformat(str(row['created_at']).replace('Z','+00:00'))
            if ts.tzinfo is None: ts=ts.replace(tzinfo=timezone.utc)
            return max(0.0,(datetime.now(timezone.utc)-ts).total_seconds()/60)
        except Exception: return None

    def evaluate(self, decision, cash_value=None):
        base=RiskGuard().evaluate(decision,cash_value)
        if not base.approved: return V13Decision(False, f'V12: {base.reason}', base.quantity, base.risk_amount)
        if db.state('emergency_stop')=='1': return V13Decision(False,'Emergency stop active')
        if db.state('safe_mode')=='1': return V13Decision(False,'Safe mode active')
        if db.state('paused')=='1': return V13Decision(False,'Paper trading paused')
        if self.trades_today() >= self.MAX_TRADES_PER_DAY:
            db.event('WARN','TRADE_FREQUENCY_LIMIT',str(self.MAX_TRADES_PER_DAY))
            return V13Decision(False,'Daily trade frequency limit reached')
        losses=self.consecutive_losses()
        if losses >= self.MAX_CONSECUTIVE_LOSSES:
            age=self.last_loss_age_minutes()
            if age is None or age < self.LOSS_COOLDOWN_MIN:
                db.set_state('paused','1'); db.event('WARN','LOSS_COOLDOWN',f'losses={losses};age={age}')
                return V13Decision(False,'Consecutive-loss cooldown active')
        return V13Decision(True,'Approved',base.quantity,base.risk_amount)
