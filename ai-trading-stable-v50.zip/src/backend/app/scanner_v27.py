from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Callable, Iterable
from .data import Candle
from .market_reliability_v26 import MarketDataValidatorV26, DataQuality, DataStatus

@dataclass(frozen=True)
class ScanCandidate:
    symbol: str
    interval: str
    last_price: float
    change_pct: float
    volume_ratio: float
    range_pct: float
    score: float
    signal: str
    reason: str
    source: str
    quality: str

@dataclass(frozen=True)
class ScanResult:
    scanned: int
    candidates: list[ScanCandidate]
    blocked: list[str]

class MarketScannerV27:
    """Paper-only market scanner. It ranks observable setups; it never executes orders."""
    def __init__(self, validator: MarketDataValidatorV26 | None = None, min_score: float = 0.70):
        self.validator = validator or MarketDataValidatorV26()
        self.min_score = min_score

    def _analyze(self, symbol: str, interval: str, candles: list[Candle], source: str, q: DataQuality) -> ScanCandidate | None:
        if not q.ok or len(candles) < 20:
            return None
        closes=[c.close for c in candles]
        vols=[c.volume for c in candles]
        last=closes[-1]
        prev=closes[-2]
        base=closes[-20]
        change=(last/base-1)*100
        avg_vol=sum(vols[-21:-1])/20 if len(vols)>=21 else sum(vols[:-1])/max(1,len(vols)-1)
        vr=vols[-1]/avg_vol if avg_vol>0 else 0.0
        window=closes[-20:]
        lo=min(window); hi=max(window)
        breakout_up=last>=hi and last>prev
        breakout_down=last<=lo and last<prev
        momentum=min(1.0, abs(change)/2.0)
        volume=min(1.0, max(0.0, (vr-0.8)/1.2))
        direction=1 if change>0 else -1 if change<0 else 0
        structure=1.0 if (breakout_up or breakout_down) else 0.5
        score=min(1.0, 0.45*momentum+0.30*volume+0.25*structure)
        signal='HOLD'
        if score>=self.min_score and direction:
            signal='BUY' if direction>0 else 'SELL'
        reason=f'20-candle momentum={change:.2f}%, volume_ratio={vr:.2f}, breakout={breakout_up or breakout_down}'
        return ScanCandidate(symbol,interval,last,change,vr,(hi-lo)/last*100 if last else 0,score,signal,reason,source,q.status.value)

    def scan(self, universe: dict[str, Callable[[], Iterable[Candle]]], now_ms: int, interval: str='5m') -> ScanResult:
        candidates=[]; blocked=[]
        for symbol, fetch in universe.items():
            try:
                cs=list(fetch())
                q=self.validator.validate(cs,now_ms,symbol)
                c=self._analyze(symbol,interval,cs,symbol,q)
                if c is not None: candidates.append(c)
                else: blocked.append(symbol)
            except Exception as exc:
                blocked.append(f'{symbol}:FETCH_ERROR')
        candidates.sort(key=lambda x:x.score, reverse=True)
        return ScanResult(len(universe),candidates,blocked)
