import threading
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from . import db
from .paper_session import PaperSession
from .analytics import record_equity

@dataclass
class SchedulerStatus:
    running: bool
    interval_seconds: int
    cycles: int
    successes: int
    failures: int
    last_cycle_at: str | None
    last_status: str | None
    last_error: str | None

class PaperScheduler:
    def __init__(self, interval_seconds=60, session=None):
        self.interval_seconds=max(1,int(interval_seconds))
        self.session=session or PaperSession()
        self._stop=threading.Event()
        self._thread=None
        self.cycles=0; self.successes=0; self.failures=0
        self.last_cycle_at=None; self.last_status=None; self.last_error=None

    def run_once(self):
        started=datetime.now(timezone.utc).isoformat()
        self.last_cycle_at=started
        try:
            report=self.session.run_cycle()
            # Always persist a valuation snapshot, including BLOCKED/SAFE_MODE cycles.
            record_equity()
            self.cycles += 1
            self.last_status=report.status
            self.last_error=report.error or None
            if report.status == 'OK': self.successes += 1
            else: self.failures += 1
            return report
        except Exception as exc:
            self.cycles += 1; self.failures += 1
            self.last_status='ERROR'; self.last_error=str(exc)
            db.set_state('safe_mode','1'); db.event('ERROR','SCHEDULER_FAILURE',str(exc))
            return None

    def _loop(self):
        while not self._stop.is_set():
            self.run_once()
            self._stop.wait(self.interval_seconds)

    def start(self):
        if self._thread and self._thread.is_alive(): return False
        self._stop.clear(); self._thread=threading.Thread(target=self._loop,daemon=True); self._thread.start(); return True

    def stop(self):
        self._stop.set()
        if self._thread: self._thread.join(timeout=min(5,self.interval_seconds+1))
        return True

    def status(self):
        return SchedulerStatus(bool(self._thread and self._thread.is_alive()),self.interval_seconds,self.cycles,self.successes,self.failures,self.last_cycle_at,self.last_status,self.last_error)
