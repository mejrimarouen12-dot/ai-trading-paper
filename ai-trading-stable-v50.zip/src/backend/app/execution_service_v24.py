from .execution_v24 import Order, OrderState, OrderStateMachineV24
from .audit_v24 import AuditTrailV24
from .recovery_v25 import RecoveryStoreV25

class ExecutionServiceV24:
    def __init__(self, recovery_path=None):
        self.machine=OrderStateMachineV24(); self.audit=AuditTrailV24()
        self.store=RecoveryStoreV25(recovery_path) if recovery_path else None
        self.recover()
    def _payload(self):
        return {'orders': {k: vars(v) for k,v in self.machine.orders.items()}, 'states': {k:v.value for k,v in self.machine.states.items()}, 'filled': self.machine.filled}
    def _persist(self):
        if self.store: self.store.save(self._payload())
    def recover(self):
        if not self.store: return {'ok':True,'recovered_orders':0,'issues':[]}
        p=self.store.load()
        if not p: return {'ok':True,'recovered_orders':0,'issues':[]}
        r=self.store.reconcile(p)
        if not r.ok: return {'ok':False,'recovered_orders':0,'issues':r.issues}
        for oid,raw in p.get('orders',{}).items(): self.machine.orders[oid]=Order(**raw)
        self.machine.states={k:OrderState(v) for k,v in p.get('states',{}).items()}
        self.machine.filled={k:float(v) for k,v in p.get('filled',{}).items()}
        return {'ok':True,'recovered_orders':r.recovered_orders,'issues':[]}
    def reconciliation(self):
        r=RecoveryStoreV25.reconcile(self._payload())
        return {'ok':r.ok,'issues':r.issues,'inflight_orders':r.recovered_orders}
    def create_order(self, order:Order):
        ok,msg=self.machine.create(order)
        self.audit.append(order.order_id,'CREATE',self.machine.states.get(order.order_id,'NONE').value if ok else 'REJECTED',msg)
        self._persist()
        return ok,msg
    def transition(self, order_id, target):
        ok,msg=self.machine.transition(order_id,target)
        state=self.machine.states.get(order_id,'UNKNOWN').value
        self.audit.append(order_id,'STATE_CHANGE',state,msg)
        self._persist()
        return ok,msg
    def fill(self, order_id, quantity):
        ok,msg=self.machine.fill(order_id,quantity)
        state=self.machine.states.get(order_id,'UNKNOWN').value
        self.audit.append(order_id,'FILL',state,msg)
        self._persist()
        return ok,msg
    def recoverable(self, order_id):
        snap=self.machine.snapshot(order_id)
        if not snap: return False
        return snap['state'] in ('SUBMITTED','PARTIALLY_FILLED','CANCEL_PENDING')
