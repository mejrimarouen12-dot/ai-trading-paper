from fastapi import APIRouter
from . import db
from .engine import cycle
from .backtest import run as run_backtest

router=APIRouter()
@router.get('/health')
def health(): return {'status':'ok','mode':'PAPER','live_trading':False}
@router.get('/agent/status')
def status(): return {'mode':'PAPER','paused':db.state('paused')=='1','safe_mode':db.state('safe_mode')=='1','emergency_stop':db.state('emergency_stop')=='1'}
@router.post('/agent/cycle')
def run_cycle(): return cycle()
@router.post('/agent/pause')
def pause(): db.set_state('paused','1'); db.event('INFO','PAUSE','Agent paused'); return status()
@router.post('/agent/resume')
def resume(): db.set_state('paused','0'); db.event('INFO','RESUME','Agent resumed'); return status()
@router.post('/safe-mode')
def safe(): db.set_state('safe_mode','1'); db.event('CRITICAL','SAFE_MODE','Safe mode enabled'); return status()
@router.post('/emergency-stop')
def stop(): db.set_state('emergency_stop','1'); db.event('CRITICAL','EMERGENCY_STOP','Emergency stop enabled'); return status()
@router.get('/portfolio')
def portfolio():
    c=db.conn(); openp=c.execute("SELECT * FROM positions WHERE status='OPEN'").fetchall(); trades=c.execute("SELECT COALESCE(SUM(pnl),0) pnl, COUNT(*) n FROM trades").fetchone(); c.close()
    return {'cash':float(db.state('cash')),'starting_balance':10000,'open_positions':len(openp),'realized_pnl':float(trades['pnl']),'closed_trades':int(trades['n'])}
@router.get('/positions')
def positions():
    c=db.conn(); rows=c.execute("SELECT * FROM positions WHERE status='OPEN' ORDER BY id DESC").fetchall(); c.close(); return [dict(r) for r in rows]
@router.get('/decisions')
def decisions():
    c=db.conn(); rows=c.execute('SELECT * FROM decisions ORDER BY id DESC LIMIT 100').fetchall(); c.close(); return [dict(r) for r in rows]
@router.get('/trades')
def trades():
    c=db.conn(); rows=c.execute('SELECT * FROM trades ORDER BY id DESC LIMIT 100').fetchall(); c.close(); return [dict(r) for r in rows]
@router.get('/events')
def events():
    c=db.conn(); rows=c.execute('SELECT * FROM events ORDER BY id DESC LIMIT 100').fetchall(); c.close(); return [dict(r) for r in rows]
@router.get('/backtest')
def backtest(symbol='BTC/USDT', bars=500): return run_backtest(symbol,bars)
