from dataclasses import dataclass, asdict
from typing import Callable, Any

@dataclass
class Check:
    name: str
    passed: bool
    detail: str

class PaperCertification:
    """Deterministic certification suite for the paper-only system.
    It verifies safety boundaries and core lifecycle behavior without live orders.
    """
    def __init__(self):
        self.checks: list[Check] = []

    def check(self, name: str, fn: Callable[[], Any]):
        try:
            result = fn()
            ok = bool(result) if not isinstance(result, (list, dict)) else True
            self.checks.append(Check(name, ok, "passed" if ok else "returned false"))
        except Exception as exc:
            self.checks.append(Check(name, False, f"{type(exc).__name__}: {exc}"))

    def run(self):
        from . import config as settings
        from .integrity import IntegrityEngine
        from .chaos import ChaosLab
        from .health import snapshot
        from . import db

        self.check("paper_mode_locked", lambda: settings.MODE == "PAPER" and settings.LIVE_TRADING is False)
        self.check("health_safe_boundary", lambda: (db.init_db(), snapshot())[1]["mode"] == "PAPER" and snapshot()["live_enabled"] is False)
        self.check("order_integrity_valid", lambda: IntegrityEngine().validate_order(order_id="cert-1", symbol="BTC/USDT", side="BUY", quantity=1.0, price=100.0) == [])
        self.check("order_integrity_invalid_rejected", lambda: "invalid_quantity" in IntegrityEngine().validate_order(order_id="cert-2", symbol="BTC/USDT", side="BUY", quantity=0, price=100.0))
        self.check("chaos_fail_safe", lambda: all(x.safe for x in ChaosLab().run_all()))
        self.check("db_roundtrip", lambda: (db.init_db(), db.set_state("certification_probe", "ok"), db.state("certification_probe") == "ok")[-1])
        self.check("no_live_execution_surface", lambda: not hasattr(settings, "live_trading_enabled") or settings.LIVE_TRADING is False)

        passed = sum(c.passed for c in self.checks)
        return {
            "certified": passed == len(self.checks),
            "passed": passed,
            "total": len(self.checks),
            "checks": [asdict(c) for c in self.checks],
            "mode": "PAPER",
            "live_enabled": False,
        }
