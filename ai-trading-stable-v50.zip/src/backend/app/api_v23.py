from fastapi import APIRouter
from .portfolio_intelligence_v23 import PortfolioIntelligenceV23, Exposure
from .expert_memory_v23 import ExpertMemoryV23
from .validation_v23 import DecisionValidatorV23

router=APIRouter(prefix='/v23',tags=['v23'])
portfolio=PortfolioIntelligenceV23(); memory=ExpertMemoryV23(); validator=DecisionValidatorV23()

@router.get('/portfolio/risk')
def portfolio_risk():
    return portfolio.assess(10000,[Exposure('BTC/USDT','BUY',1200,.12)]) .__dict__

@router.get('/portfolio/correlation')
def correlation(): return portfolio.correlation_matrix(['BTC/USDT','ETH/USDT','SOL/USDT'])

@router.post('/decision/validate')
def validate(decision:dict):
    ok,reason=validator.validate(decision); return {'valid':ok,'reason':reason}

@router.get('/memory/review')
def memory_review(): return memory.review()
