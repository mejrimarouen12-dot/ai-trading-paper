from fastapi import APIRouter
from . import db
from .analytics import snapshot, performance, record_equity
from .paper_session import PaperSession

router=APIRouter(prefix='/v10',tags=['v10-monitoring'])

@router.get('/dashboard')
def dashboard():
    return {'mode':'PAPER','live_orders':False,'current':snapshot(),'performance':performance(),'safety':{'paused':db.state('paused')=='1','safe_mode':db.state('safe_mode')=='1','emergency_stop':db.state('emergency_stop')=='1'}}

@router.get('/performance')
def perf(): return performance()

@router.get('/equity')
def equity():
    c=db.conn(); rows=c.execute('SELECT * FROM equity ORDER BY id DESC LIMIT 300').fetchall(); c.close(); return [dict(r) for r in reversed(rows)]

@router.post('/paper/cycle')
def cycle():
    report=PaperSession().run_cycle()
    state=record_equity()
    return {'cycle':report.__dict__,'account':state}
