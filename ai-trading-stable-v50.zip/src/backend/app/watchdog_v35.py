from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from . import db, config

@dataclass
class WatchdogStatus:
    status: str
    healthy: bool
    runner_state: str
    last_cycle_at: str | None
    age_seconds: float | None
    stale_after_seconds: int
    live_enabled: bool = False

class PaperWatchdogV35:
    VERSION = "35.0"
    DEFAULT_STALE_AFTER = 900  # 15 minutes; operator can override for diagnostics only.

    def _parse_age(self, stamp):
        if not stamp:
            return None
        try:
            dt = datetime.fromisoformat(stamp.replace("Z", "+00:00"))
            return max(0.0, (datetime.now(timezone.utc) - dt).total_seconds())
        except (TypeError, ValueError):
            return None

    def inspect(self, stale_after_seconds=None):
        try:
            threshold = int(stale_after_seconds if stale_after_seconds is not None else self.DEFAULT_STALE_AFTER)
        except (TypeError, ValueError):
            threshold = self.DEFAULT_STALE_AFTER
        threshold = max(1, min(threshold, 86400))

        last = db.state("paper_runner_last_at")
        age = self._parse_age(last)
        stop = db.state("paper_runner_stop") == "1"
        locked = db.state("paper_runner_lock") == "1"
        safety = any(db.state(k) == "1" for k in ("paused", "safe_mode", "emergency_stop"))

        if safety:
            status = "SAFE_BLOCKED"
        elif stop:
            status = "STOP_REQUESTED"
        elif locked:
            status = "RUNNING"
        elif age is None:
            status = "NO_HEARTBEAT"
        elif age > threshold:
            status = "STALE_HEARTBEAT"
        else:
            status = "HEALTHY"

        healthy = status in {"HEALTHY", "RUNNING"}
        return WatchdogStatus(status, healthy, status, last, age, threshold)

    def enforce(self, stale_after_seconds=None):
        report = self.inspect(stale_after_seconds)
        if report.status == "STALE_HEARTBEAT":
            db.set_state("safe_mode", "1")
            db.event("ERROR", "PAPER_WATCHDOG_STALE", f"paper runner heartbeat stale: {report.age_seconds:.1f}s")
            return {**asdict(report), "action": "SAFE_MODE"}
        if report.status == "NO_HEARTBEAT":
            db.event("WARN", "PAPER_WATCHDOG_NO_HEARTBEAT", "no paper runner heartbeat recorded")
            return {**asdict(report), "action": "NO_NEW_TRADE"}
        return {**asdict(report), "action": "NONE"}
