from datetime import datetime, timezone, timedelta
from . import db
from .analytics import performance, snapshot

def _since(days):
    return (datetime.now(timezone.utc)-timedelta(days=days)).isoformat()

def period_report(days=1):
    since=_since(days); c=db.conn()
    trades=c.execute('SELECT pnl, fees, exit_reason, created_at FROM trades WHERE created_at>=? ORDER BY id',(since,)).fetchall()
    events=c.execute('SELECT level,event_type,message,created_at FROM events WHERE created_at>=? ORDER BY id',(since,)).fetchall()
    equity=c.execute('SELECT equity,created_at FROM equity WHERE created_at>=? ORDER BY id',(since,)).fetchall(); c.close()
    pnls=[float(r['pnl']) for r in trades]
    start=float(equity[0]['equity']) if equity else snapshot()['equity']
    end=float(equity[-1]['equity']) if equity else snapshot()['equity']
    return {'period_days':days,'from':since,'to':datetime.now(timezone.utc).isoformat(),'trade_count':len(pnls),'net_pnl':sum(pnls),'wins':sum(x>0 for x in pnls),'losses':sum(x<0 for x in pnls),'equity_start':start,'equity_end':end,'return_pct':((end/start)-1)*100 if start else 0.0,'events':len(events),'errors':sum(r['level']=='ERROR' for r in events)}

def daily_report(): return period_report(1)
def weekly_report(): return period_report(7)

def recovery_status():
    c=db.conn(); rows=c.execute("SELECT event_type,message,created_at FROM events WHERE level='ERROR' ORDER BY id DESC LIMIT 20").fetchall(); c.close()
    return {'safe_mode':db.state('safe_mode')=='1','paused':db.state('paused')=='1','emergency_stop':db.state('emergency_stop')=='1','recent_errors':[dict(r) for r in rows]}
