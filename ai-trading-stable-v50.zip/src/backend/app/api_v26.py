from fastapi import APIRouter
from .market_reliability_v26 import DataQuality, DataStatus, MarketDataValidatorV26
router=APIRouter(prefix='/v26',tags=['v26'])
_validator=MarketDataValidatorV26()
@router.get('/market-data/policy')
def policy():
    return {'mode':'PAPER','live_enabled':False,'max_age_ms':_validator.max_age_ms,'expected_interval_ms':_validator.expected_interval_ms,'failover_policy':'primary -> secondary -> NO_NEW_TRADE'}
