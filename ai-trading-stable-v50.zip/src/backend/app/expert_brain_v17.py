from dataclasses import dataclass
from .decision_validator_v17 import DecisionValidatorV17

@dataclass
class BrainResult:
    decision: dict
    valid: bool
    reason: str

class ExpertBrainV17:
    def __init__(self): self.validator=DecisionValidatorV17()
    def synthesize(self, council, confluence=None, quality=None):
        action=council.decision
        if action not in ("BUY","SELL") or getattr(council,"contrarian_risk","")=="High":
            d={"decision":"HOLD","confidence":min(0.99,float(council.confidence)),"thesis":council.rationale,"invalidation_condition":"Council alignment lost"}
        else:
            # Conservative synthetic levels for paper validation only.
            p=float(getattr(confluence,"price",0) or 0)
            d={"decision":action,"confidence":float(council.confidence),"entry":p,"stop_loss":p*0.99 if action=="BUY" else p*1.01,"take_profit":p*1.02 if action=="BUY" else p*0.98,"thesis":council.rationale,"invalidation_condition":"Council alignment lost","contrarian_risk":council.contrarian_risk}
        v=self.validator.validate(d)
        return BrainResult(v.normalized,v.valid,v.reason)
