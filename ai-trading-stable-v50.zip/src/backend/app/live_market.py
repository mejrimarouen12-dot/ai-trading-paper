"""Read-only public market adapter. Never places orders."""
import json, time, urllib.request
from dataclasses import dataclass
from .market import Candle, MarketEngine

BINANCE_SYMBOLS = {"BTC/USDT":"BTCUSDT","ETH/USDT":"ETHUSDT","SOL/USDT":"SOLUSDT"}
INTERVALS = {"5m":"5m","15m":"15m","1h":"1h","4h":"4h"}

class MarketDataError(RuntimeError): pass

class PublicMarketAdapter:
    def __init__(self, base_url="https://api.binance.com", timeout=8):
        self.base_url=base_url.rstrip('/')
        self.timeout=timeout

    def candles(self, symbol, timeframe="5m", limit=250):
        if symbol not in BINANCE_SYMBOLS or timeframe not in INTERVALS:
            raise MarketDataError("Unsupported symbol/timeframe")
        url=f"{self.base_url}/api/v3/klines?symbol={BINANCE_SYMBOLS[symbol]}&interval={INTERVALS[timeframe]}&limit={int(limit)}"
        try:
            req=urllib.request.Request(url, headers={"User-Agent":"AI-Trading-Paper/9.0"})
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                data=json.loads(r.read().decode())
            if not isinstance(data,list) or len(data)<60: raise MarketDataError("Insufficient market data")
            return [Candle(int(x[0]),float(x[1]),float(x[2]),float(x[3]),float(x[4]),float(x[5])) for x in data]
        except Exception as e:
            raise MarketDataError(str(e)) from e

    def snapshot(self, symbol, timeframe="5m"):
        candles=self.candles(symbol,timeframe)
        return MarketEngine().snapshot_from_candles(symbol,candles)
