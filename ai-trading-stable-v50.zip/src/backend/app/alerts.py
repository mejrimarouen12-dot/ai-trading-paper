from . import db

def alert(level, code, message):
    db.event(level, f'ALERT_{code}', message)

def critical(code, message):
    alert('CRITICAL', code, message)
    db.set_state('safe_mode','1')
