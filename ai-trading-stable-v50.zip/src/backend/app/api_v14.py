from fastapi import APIRouter
from .quality_v14 import SetupQualityEngine
from . import db
router=APIRouter(prefix='/v14',tags=['v14-quality'])

@router.get('/quality')
def quality():
    c=db.conn()
    row=c.execute('SELECT COUNT(*) n, COALESCE(AVG(score),0) avg_score, COALESCE(SUM(approved),0) approved FROM setup_quality').fetchone()
    recent=c.execute('SELECT symbol,decision_id,score,approved,reason,created_at FROM setup_quality ORDER BY id DESC LIMIT 20').fetchall()
    c.close()
    return {'mode':'PAPER','live_orders':False,'threshold':SetupQualityEngine.MIN_SCORE,
            'evaluations':int(row['n']),'average_score':float(row['avg_score'] or 0),'approved':int(row['approved'] or 0),
            'recent':[dict(r) for r in recent]}
