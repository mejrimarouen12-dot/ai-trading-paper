from fastapi import APIRouter
from .certification import PaperCertification

router = APIRouter(prefix="/v8", tags=["v8-certification"])

@router.get("/certification")
def certification():
    return PaperCertification().run()
