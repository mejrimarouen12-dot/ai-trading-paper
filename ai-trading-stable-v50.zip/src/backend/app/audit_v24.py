from dataclasses import dataclass, asdict
from datetime import datetime, timezone
import hashlib, json

@dataclass(frozen=True)
class AuditEvent:
    sequence:int
    event_id:str
    order_id:str
    event_type:str
    state:str
    message:str
    timestamp:str
    previous_hash:str
    event_hash:str

class AuditTrailV24:
    def __init__(self): self.events=[]
    def append(self, order_id, event_type, state, message=''):
        seq=len(self.events)+1
        ts=datetime.now(timezone.utc).isoformat()
        prev=self.events[-1].event_hash if self.events else 'GENESIS'
        payload=f'{seq}|{order_id}|{event_type}|{state}|{message}|{ts}|{prev}'
        h=hashlib.sha256(payload.encode()).hexdigest()
        e=AuditEvent(seq,h[:16],order_id,event_type,state,message,ts,prev,h)
        self.events.append(e); return e
    def verify(self):
        prev='GENESIS'
        for e in self.events:
            payload=f'{e.sequence}|{e.order_id}|{e.event_type}|{e.state}|{e.message}|{e.timestamp}|{e.previous_hash}'
            if e.previous_hash!=prev or hashlib.sha256(payload.encode()).hexdigest()!=e.event_hash: return False
            prev=e.event_hash
        return True
    def export(self): return [asdict(e) for e in self.events]
