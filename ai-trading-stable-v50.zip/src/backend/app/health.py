from datetime import datetime, timezone
from . import db

def utcnow():
    return datetime.now(timezone.utc)

def parse(ts):
    try: return datetime.fromisoformat(ts)
    except Exception: return None

def snapshot():
    hb = db.state('heartbeat_at')
    last = parse(hb) if hb else None
    age = None if not last else max(0, (utcnow()-last).total_seconds())
    return {
        'status': 'ok' if age is None or age < 60 else 'degraded',
        'heartbeat_at': hb,
        'heartbeat_age_seconds': age,
        'paused': db.state('paused') == '1',
        'safe_mode': db.state('safe_mode') == '1',
        'emergency_stop': db.state('emergency_stop') == '1',
        'mode': 'PAPER',
        'live_enabled': False,
    }

def heartbeat():
    db.set_state('heartbeat_at', utcnow().isoformat())
