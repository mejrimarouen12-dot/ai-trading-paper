from fastapi import APIRouter
from .final_audit_v32 import FinalPaperAuditV32

router = APIRouter(prefix='/v32', tags=['v32-final-paper'])

@router.get('/final-audit')
def final_audit():
    return FinalPaperAuditV32().run()
