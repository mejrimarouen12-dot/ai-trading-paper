from .market import MarketEngine
from .expert import decide
from .config import FEE_RATE, RISK_PER_TRADE

def run(symbol='BTC/USDT', bars=500, starting=10000):
    m=MarketEngine(); candles=m.candles(symbol,max(bars,80)); cash=starting; position=None; trades=[]; peak=starting; max_dd=0.0
    for i in range(60,len(candles)):
        window=candles[:i+1]; s=m.snapshot_from_candles(symbol,window); d=decide(s); px=s.price
        if position:
            side=position['side']; stop=position['stop']; target=position['target']; exit_px=None; reason=None
            if side=='BUY':
                if window[-1].low <= stop: exit_px=stop; reason='STOP_LOSS'
                elif window[-1].high >= target: exit_px=target; reason='TAKE_PROFIT'
            else:
                if window[-1].high >= stop: exit_px=stop; reason='STOP_LOSS'
                elif window[-1].low <= target: exit_px=target; reason='TAKE_PROFIT'
            if exit_px is not None:
                qty=position['qty']; gross=(exit_px-position['entry'])*qty if side=='BUY' else (position['entry']-exit_px)*qty
                fees=(position['entry']+exit_px)*qty*FEE_RATE; pnl=gross-fees; cash+=pnl
                trades.append({'pnl':pnl,'reason':reason}); position=None
        if not position and d.get('decision') in ('BUY','SELL') and d.get('entry'):
            entry=float(d['entry']); stop=float(d['stop_loss']); target=float(d['take_profit']); risk=abs(entry-stop)
            if risk>0:
                qty=(cash*RISK_PER_TRADE)/risk
                position={'side':d['decision'],'entry':entry,'stop':stop,'target':target,'qty':qty}
        equity=cash
        if position:
            qty=position['qty']; equity += ((px-position['entry'])*qty if position['side']=='BUY' else (position['entry']-px)*qty)
        peak=max(peak,equity); max_dd=max(max_dd,(peak-equity)/peak if peak else 0)
    if position:
        px=candles[-1].close; qty=position['qty']; pnl=((px-position['entry'])*qty if position['side']=='BUY' else (position['entry']-px)*qty)-((position['entry']+px)*qty*FEE_RATE); cash+=pnl; trades.append({'pnl':pnl,'reason':'END_OF_TEST'})
    wins=sum(1 for t in trades if t['pnl']>0); losses=sum(1 for t in trades if t['pnl']<=0); gross_profit=sum(t['pnl'] for t in trades if t['pnl']>0); gross_loss=-sum(t['pnl'] for t in trades if t['pnl']<0)
    return {'symbol':symbol,'bars':bars,'starting_balance':starting,'ending_balance':round(cash,2),'net_pnl':round(cash-starting,2),'return_pct':round((cash/starting-1)*100,2),'trades':len(trades),'wins':wins,'losses':losses,'win_rate_pct':round(wins/len(trades)*100,2) if trades else 0,'profit_factor':round(gross_profit/gross_loss,2) if gross_loss else None,'max_drawdown_pct':round(max_dd*100,2)}
