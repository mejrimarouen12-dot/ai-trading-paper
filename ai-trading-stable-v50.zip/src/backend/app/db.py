import sqlite3
from pathlib import Path
from datetime import datetime, timezone

DB_PATH = Path(__file__).resolve().parents[2] / "trading.db"

def now(): return datetime.now(timezone.utc).isoformat()

def conn():
    c = sqlite3.connect(DB_PATH, timeout=10)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    c = conn()
    c.executescript('''
    CREATE TABLE IF NOT EXISTS system_state (key TEXT PRIMARY KEY, value TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS decisions (id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT, decision TEXT, confidence REAL, regime TEXT, entry REAL, stop_loss REAL, take_profit REAL, thesis TEXT, invalidation TEXT, contrarian_risk TEXT, reason TEXT, created_at TEXT);
    CREATE TABLE IF NOT EXISTS positions (id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT UNIQUE, side TEXT, entry_price REAL, quantity REAL, stop_loss REAL, take_profit REAL, status TEXT, opened_at TEXT, closed_at TEXT);
    CREATE TABLE IF NOT EXISTS trades (id INTEGER PRIMARY KEY AUTOINCREMENT, position_id INTEGER, symbol TEXT, side TEXT, entry_price REAL, exit_price REAL, quantity REAL, fees REAL, pnl REAL, exit_reason TEXT, created_at TEXT);
    CREATE TABLE IF NOT EXISTS equity (id INTEGER PRIMARY KEY AUTOINCREMENT, balance REAL, equity REAL, created_at TEXT);
    CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY AUTOINCREMENT, level TEXT, event_type TEXT, message TEXT, created_at TEXT);
    CREATE TABLE IF NOT EXISTS decision_audits (id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT, decision_id INTEGER, context_json TEXT, verdict TEXT, created_at TEXT);
    CREATE TABLE IF NOT EXISTS setup_quality (id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT, decision_id INTEGER, score REAL, approved INTEGER, reason TEXT, factors_json TEXT, created_at TEXT);
    CREATE TABLE IF NOT EXISTS paper_cycles (id INTEGER PRIMARY KEY AUTOINCREMENT, cycle INTEGER, status TEXT, decisions INTEGER, executed INTEGER, rejected INTEGER, closed INTEGER, started_at TEXT, finished_at TEXT);
    ''')
    c.execute("INSERT OR IGNORE INTO system_state(key,value) VALUES('paused','0')")
    c.execute("INSERT OR IGNORE INTO system_state(key,value) VALUES('safe_mode','0')")
    c.execute("INSERT OR IGNORE INTO system_state(key,value) VALUES('emergency_stop','0')")
    c.execute("INSERT OR IGNORE INTO system_state(key,value) VALUES('cash','10000')")
    c.commit(); c.close()

def state(key):
    c=conn(); r=c.execute('SELECT value FROM system_state WHERE key=?',(key,)).fetchone(); c.close(); return r['value'] if r else None

def set_state(key,value):
    c=conn(); c.execute('INSERT INTO system_state(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',(key,str(value))); c.commit(); c.close()

def event(level,typ,msg):
    c=conn(); c.execute('INSERT INTO events(level,event_type,message,created_at) VALUES(?,?,?,?)',(level,typ,msg,now())); c.commit(); c.close()
