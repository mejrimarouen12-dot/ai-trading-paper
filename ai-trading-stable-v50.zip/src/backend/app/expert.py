from .market import Snapshot

def decide(s: Snapshot):
    # Deterministic baseline expert. It deliberately refuses marginal setups.
    if not s.quality: return {"decision":"HOLD","confidence":0,"reason":"Market data quality gate failed"}
    if s.regime=='TREND_UP' and s.rsi>=55 and s.volume_ratio>=1.0:
        entry=s.price; stop=entry-s.atr*1.5; target=entry+s.atr*3
        return {"decision":"BUY","confidence":0.72,"entry":entry,"stop_loss":stop,"take_profit":target,"regime":s.regime,"thesis":"Trend and momentum align above key moving averages.","invalidation":"Price closes below protective stop / trend invalidation.","contrarian_risk":"Momentum can fail if volatility expands abruptly.","reason":"Multi-factor alignment"}
    if s.regime=='TREND_DOWN' and s.rsi<=45 and s.volume_ratio>=1.0:
        entry=s.price; stop=entry+s.atr*1.5; target=entry-s.atr*3
        return {"decision":"SELL","confidence":0.72,"entry":entry,"stop_loss":stop,"take_profit":target,"regime":s.regime,"thesis":"Downtrend and momentum align below key moving averages.","invalidation":"Price closes above protective stop / trend invalidation.","contrarian_risk":"Downside momentum can reverse sharply.","reason":"Multi-factor alignment"}
    return {"decision":"HOLD","confidence":0.55,"regime":s.regime,"reason":"Evidence is not strong enough for a new position"}
