import sqlite3
from .db import conn

class ObservabilityV29:
    def snapshot(self):
        c=conn()
        def one(q,args=()):
            r=c.execute(q,args).fetchone(); return dict(r) if r else {}
        current=one('SELECT balance,equity,created_at FROM equity ORDER BY id DESC LIMIT 1')
        trades=one("SELECT COUNT(*) AS total, COALESCE(SUM(pnl),0) AS pnl, COALESCE(SUM(fees),0) AS fees, COALESCE(SUM(CASE WHEN pnl>0 THEN 1 ELSE 0 END),0) AS wins FROM trades")
        positions=one("SELECT COUNT(*) AS open_positions FROM positions WHERE status='OPEN'")
        decisions=one('SELECT COUNT(*) AS total FROM decisions')
        events=one("SELECT COUNT(*) AS total, COALESCE(SUM(CASE WHEN level='ERROR' THEN 1 ELSE 0 END),0) AS errors FROM events")
        audits=one('SELECT COUNT(*) AS total FROM decision_audits')
        setup=one('SELECT COUNT(*) AS total, COALESCE(AVG(score),0) AS avg_score FROM setup_quality')
        c.close()
        equity=self._curve()
        vals=[float(x['equity']) for x in equity]
        peak=None; max_dd=0.0
        for v in vals:
            peak=v if peak is None else max(peak,v)
            if peak: max_dd=max(max_dd,(peak-v)/peak*100)
        total=int(trades.get('total',0)); wins=int(trades.get('wins',0))
        return {'mode':'PAPER','live_enabled':False,'current':current or {'balance':10000.0,'equity':10000.0},'trades':trades,'positions':positions,'decisions':decisions,'events':events,'audits':audits,'setup_quality':setup,'performance':{'win_rate_pct':(wins/total*100 if total else 0.0),'max_drawdown_pct':max_dd,'equity_curve':equity}}

    def _curve(self):
        c=conn(); rows=c.execute('SELECT id,balance,equity,created_at FROM equity ORDER BY id ASC').fetchall(); c.close()
        return [dict(r) for r in rows]

    def events(self,limit=50):
        c=conn(); rows=c.execute('SELECT id,level,event_type,message,created_at FROM events ORDER BY id DESC LIMIT ?',(int(limit),)).fetchall(); c.close(); return [dict(r) for r in rows]
