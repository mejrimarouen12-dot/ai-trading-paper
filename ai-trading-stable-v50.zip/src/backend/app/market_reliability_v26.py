from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
from typing import Callable, Iterable
from .data import Candle

class DataStatus(str, Enum):
    FRESH='FRESH'; STALE='STALE'; INVALID='INVALID'; FAILOVER='FAILOVER'; UNAVAILABLE='UNAVAILABLE'

@dataclass(frozen=True)
class DataQuality:
    ok: bool
    status: DataStatus
    issues: tuple[str,...]
    candle_count: int
    source: str
    last_ts: int | None

class MarketDataValidatorV26:
    def __init__(self, max_age_ms: int = 90_000, expected_interval_ms: int = 300_000):
        self.max_age_ms=max_age_ms; self.expected_interval_ms=expected_interval_ms

    def validate(self, candles: Iterable[Candle], now_ms: int, source: str='unknown') -> DataQuality:
        cs=list(candles); issues=[]
        if not cs: return DataQuality(False,DataStatus.UNAVAILABLE,('NO_CANDLES',),0,source,None)
        prev=None
        for c in cs:
            vals=(c.open,c.high,c.low,c.close,c.volume)
            if any(v != v or v in (float('inf'),float('-inf')) for v in vals): issues.append(f'{c.ts}:NON_FINITE')
            if min(c.open,c.close,c.low,c.high) <= 0 or c.volume < 0: issues.append(f'{c.ts}:INVALID_VALUE')
            if c.high < max(c.open,c.close) or c.low > min(c.open,c.close) or c.high < c.low: issues.append(f'{c.ts}:OHLC_INVALID')
            if prev is not None:
                if c.ts <= prev.ts: issues.append(f'{c.ts}:TIMESTAMP_NOT_INCREASING')
                elif c.ts-prev.ts > self.expected_interval_ms*2: issues.append(f'{c.ts}:GAP')
            prev=c
        age=max(0,now_ms-cs[-1].ts)
        if age > self.max_age_ms: issues.append(f'STALE:{age}')
        if issues:
            status=DataStatus.STALE if any(x.startswith('STALE:') for x in issues) and len(issues)==1 else DataStatus.INVALID
            return DataQuality(False,status,tuple(issues),len(cs),source,cs[-1].ts)
        return DataQuality(True,DataStatus.FRESH,(),len(cs),source,cs[-1].ts)

@dataclass(frozen=True)
class SourceResult:
    source: str
    candles: list[Candle] | None
    error: str | None = None

class FailoverMarketFeedV26:
    """Deterministic primary/secondary feed selector. Invalid or stale primary data is never trusted."""
    def __init__(self, primary: Callable[[], Iterable[Candle]], secondary: Callable[[], Iterable[Candle]], validator: MarketDataValidatorV26 | None=None):
        self.primary=primary; self.secondary=secondary; self.validator=validator or MarketDataValidatorV26()
        self.last_quality: DataQuality | None=None

    def fetch(self, now_ms: int) -> SourceResult:
        attempts=(('primary',self.primary),('secondary',self.secondary))
        first_issue=None
        for name,fn in attempts:
            try:
                cs=list(fn()); q=self.validator.validate(cs,now_ms,name)
                if q.ok:
                    self.last_quality=q
                    return SourceResult(name,cs)
                first_issue=q
            except Exception as e:
                first_issue=e
        if isinstance(first_issue,DataQuality):
            self.last_quality=DataQuality(False,DataStatus.UNAVAILABLE,first_issue.issues,first_issue.candle_count,first_issue.source,first_issue.last_ts)
            return SourceResult('none',None,'ALL_SOURCES_INVALID')
        self.last_quality=DataQuality(False,DataStatus.UNAVAILABLE,('ALL_SOURCES_FAILED',),0,'none',None)
        return SourceResult('none',None,str(first_issue) if first_issue else 'NO_SOURCE')
