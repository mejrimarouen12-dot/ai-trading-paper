from fastapi import APIRouter
from .confluence_v15 import MultiTimeframeConfluence, FRAMES
from . import db
router=APIRouter(prefix='/v15',tags=['v15-confluence'])

@router.get('/confluence')
def confluence_status():
    return {'mode':'PAPER','live_orders':False,'frames':list(FRAMES),
            'min_confluence':MultiTimeframeConfluence.MIN_CONFLUENCE,
            'min_directional_agreement':MultiTimeframeConfluence.MIN_DIRECTIONAL_AGREEMENT,
            'risk_guard_authority':'Risk Guard remains final order gate',
            'safe_mode':db.state('safe_mode')=='1'}
