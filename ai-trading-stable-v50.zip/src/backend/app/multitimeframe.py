from __future__ import annotations
from .data import Candle
from .indicators import ema,rsi

def score(candles:list[Candle])->dict:
    closes=[c.close for c in candles]
    e20=ema(closes,20); e50=ema(closes,50); rv=rsi(closes)
    if e20 is None or e50 is None or rv is None:return {"regime":"UNKNOWN","bias":0}
    bias=1 if e20>e50 else -1
    if rv>70 or rv<30:bias*=0.5
    return {"regime":"UPTREND" if bias>0 else "DOWNTREND","bias":bias,"ema20":e20,"ema50":e50,"rsi":rv}

def consensus(frames:dict[str,list[Candle]])->dict:
    rows={k:score(v) for k,v in frames.items()}; vals=[r["bias"] for r in rows.values() if r["bias"]]
    total=sum(vals); return {"frames":rows,"consensus":"BULLISH" if total>0.5 else "BEARISH" if total<-0.5 else "MIXED","score":total}
