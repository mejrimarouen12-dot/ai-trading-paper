from fastapi import APIRouter
from .runner_v34 import PaperRunnerV34

router = APIRouter(prefix="/v34", tags=["v34-paper-runner"])
_runner = PaperRunnerV34()

@router.get("/status")
def status():
    return _runner.status().__dict__

@router.post("/run-once")
def run_once():
    return _runner.run_once()

@router.post("/stop")
def stop():
    return _runner.request_stop().__dict__
