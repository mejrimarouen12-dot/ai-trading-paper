from fastapi import APIRouter
from .operations_v36 import PaperOperationsV36

router = APIRouter(prefix="/v36", tags=["v36-paper-operations"])
_ops = PaperOperationsV36()

@router.get("/summary")
def summary():
    return _ops.summary()

@router.get("/history")
def history(limit: int = 50):
    return {"version": _ops.VERSION, "items": _ops.history(limit)}
