from fastapi import APIRouter
from .backtest_v28 import AdvancedBacktesterV28
router=APIRouter(prefix='/v28',tags=['v28'])
_bt=AdvancedBacktesterV28()
@router.get('/policy')
def policy():
    return {'mode':'PAPER','live_enabled':False,'purpose':'advanced_backtesting_and_stress','lookahead_protection':True}
@router.get('/health')
def health():
    return {'ok':True,'backtester':'ready','execution':'disabled'}
