from __future__ import annotations
from .data import Candle

def ema(values:list[float], period:int)->float|None:
    if len(values)<period:return None
    k=2/(period+1); e=sum(values[:period])/period
    for v in values[period:]: e=v*k+e*(1-k)
    return e

def rsi(values:list[float], period:int=14)->float|None:
    if len(values)<period+1:return None
    gains=[]; losses=[]
    for a,b in zip(values[-period-1:-1],values[-period:]):
        d=b-a; gains.append(max(d,0)); losses.append(max(-d,0))
    ag=sum(gains)/period; al=sum(losses)/period
    if al==0:return 100.0
    return 100-100/(1+ag/al)

def atr(candles:list[Candle], period:int=14)->float|None:
    if len(candles)<period+1:return None
    trs=[]
    for p,c in zip(candles[-period-1:-1],candles[-period:]):
        trs.append(max(c.high-c.low,abs(c.high-p.close),abs(c.low-p.close)))
    return sum(trs)/period
