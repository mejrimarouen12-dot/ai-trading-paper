from dataclasses import dataclass
from datetime import datetime, timezone
import os
from . import db, config

@dataclass(frozen=True)
class ReleaseCheck:
    name: str
    ok: bool
    detail: str

class ReleaseV50:
    VERSION = "50.0"
    MODE = "PAPER"

    @classmethod
    def checks(cls):
        live_raw = os.getenv("LIVE_TRADING", "false").strip().lower()
        withdrawals_raw = os.getenv("ALLOW_WITHDRAWALS", "false").strip().lower()
        mode = os.getenv("MODE", "PAPER").strip().upper()
        return [
            ReleaseCheck("paper_mode", mode == "PAPER", "V50 only permits PAPER mode"),
            ReleaseCheck("live_disabled", live_raw not in {"1", "true", "yes", "on"}, "LIVE trading is hard-disabled"),
            ReleaseCheck("withdrawals_disabled", withdrawals_raw not in {"1", "true", "yes", "on"}, "withdrawals are disabled"),
            ReleaseCheck("config_live_flag", config.LIVE_TRADING is False, "application config cannot enable live trading"),
            ReleaseCheck("paper_balance", config.STARTING_BALANCE > 0, "paper starting balance is positive"),
            ReleaseCheck("risk_limit", 0 < config.RISK_PER_TRADE <= 0.02, "risk per trade is within the paper safety ceiling"),
            ReleaseCheck("position_limit", 1 <= config.MAX_OPEN_POSITIONS <= 20, "open position cap is bounded"),
            ReleaseCheck("exchange_secrets_absent", not any(k in os.environ for k in ("BINANCE_SECRET_KEY", "EXCHANGE_SECRET_KEY", "EXCHANGE_API_SECRET")), "exchange secrets are not required for the paper release"),
        ]

    @classmethod
    def manifest(cls):
        checks = cls.checks()
        return {
            "release": "AI Trading — Stable Paper Release",
            "version": cls.VERSION,
            "mode": cls.MODE,
            "live_enabled": False,
            "withdrawals_enabled": False,
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "checks": [c.__dict__ for c in checks],
            "ready": all(c.ok for c in checks),
        }

    @classmethod
    def evaluation(cls):
        db.init_db()
        c = db.conn()
        trades = c.execute("SELECT COUNT(*) n, COALESCE(SUM(pnl),0) pnl, COALESCE(SUM(fees),0) fees FROM trades").fetchone()
        cycles = c.execute("SELECT COUNT(*) n, COALESCE(SUM(decisions),0) decisions, COALESCE(SUM(executed),0) executed, COALESCE(SUM(rejected),0) rejected, COALESCE(SUM(closed),0) closed FROM paper_cycles").fetchone()
        positions = c.execute("SELECT COUNT(*) n FROM positions WHERE status='OPEN'").fetchone()
        c.close()
        return {
            "version": cls.VERSION,
            "mode": cls.MODE,
            "live_enabled": False,
            "withdrawals_enabled": False,
            "cycles": int(cycles[0]),
            "decisions": int(cycles[1]),
            "executed": int(cycles[2]),
            "rejected": int(cycles[3]),
            "closed": int(cycles[4]),
            "closed_trades": int(trades[0]),
            "realized_pnl": float(trades[1]),
            "fees": float(trades[2]),
            "open_positions": int(positions[0]),
        }
