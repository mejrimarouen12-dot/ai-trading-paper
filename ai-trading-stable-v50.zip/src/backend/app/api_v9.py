from fastapi import APIRouter
from .paper_session import PaperSession

router=APIRouter(prefix='/v9',tags=['v9-paper'])

@router.get('/market-source')
def market_source():
    return {'mode':'PAPER','market_data':'PUBLIC_READ_ONLY','execution':'PAPER_ONLY','live_orders':False}

@router.post('/paper/cycle')
def paper_cycle():
    return PaperSession().run_cycle().__dict__
