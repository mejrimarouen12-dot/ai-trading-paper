from . import db
from .market import MarketEngine
from .expert import decide
from .paper import execute, open_positions, mark_and_exit
from .intelligence import record_decision_audit
from .quality_v14 import SetupQualityEngine, record_quality

market=MarketEngine()

def cycle():
    results=[]
    if db.state('paused')=='1' or db.state('safe_mode')=='1' or db.state('emergency_stop')=='1':
        db.event('WARN','CYCLE_BLOCKED','Agent is paused or in safety state')
        return [{'status':'blocked'}]
    snapshots={}
    for symbol in ['BTC/USDT','ETH/USDT','SOL/USDT']:
        s=market.snapshot(symbol); snapshots[symbol]=s.price; d=decide(s)
        quality=SetupQualityEngine().evaluate(s,d)
        if d.get('decision') in ('BUY','SELL') and not quality.approved:
            d=dict(d); d['decision']='HOLD'; d['reason']=f'V14: {quality.reason}'; d['quality_score']=quality.score
        c=db.conn(); c.execute('INSERT INTO decisions(symbol,decision,confidence,regime,entry,stop_loss,take_profit,thesis,invalidation,contrarian_risk,reason,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',(symbol,d.get('decision'),d.get('confidence',0),d.get('regime'),d.get('entry'),d.get('stop_loss'),d.get('take_profit'),d.get('thesis'),d.get('invalidation'),d.get('contrarian_risk'),d.get('reason'),db.now())); c.commit(); c.close()
        c2=db.conn(); row=c2.execute('SELECT id FROM decisions WHERE symbol=? ORDER BY id DESC LIMIT 1',(symbol,)).fetchone(); c2.close(); record_quality(symbol, row['id'] if row else None, quality)
        if d.get('decision') in ('BUY','SELL'):
            ok,msg=execute(symbol,d); verdict='EXECUTED' if ok else 'REJECTED'
            record_decision_audit(symbol,d,{'price':s.price,'regime':s.regime,'indicators':getattr(s,'indicators',{})},verdict)
            results.append({'symbol':symbol,'decision':d,'executed':ok,'detail':msg})
        else:
            record_decision_audit(symbol,d,{'price':s.price,'regime':s.regime,'indicators':getattr(s,'indicators',{})},'HOLD')
            results.append({'symbol':symbol,'decision':d,'executed':False,'detail':'HOLD'})
    closed=mark_and_exit(snapshots)
    if closed: db.event('INFO','POSITIONS_CLOSED',str(closed))
    return results
