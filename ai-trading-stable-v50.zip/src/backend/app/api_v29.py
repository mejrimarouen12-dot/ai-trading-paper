from fastapi import APIRouter, Query
from .observability_v29 import ObservabilityV29
from . import db
router=APIRouter(prefix='/v29',tags=['v29'])
_obs=ObservabilityV29()

@router.get('/dashboard')
def dashboard():
    s=_obs.snapshot()
    s['system']={'paused':db.state('paused')=='1','safe_mode':db.state('safe_mode')=='1','emergency_stop':db.state('emergency_stop')=='1','healthy':db.state('safe_mode')!='1' and db.state('emergency_stop')!='1'}
    return s

@router.get('/events')
def events(limit:int=Query(50,ge=1,le=200)):
    return {'events':_obs.events(limit)}

@router.get('/health')
def health():
    s=_obs.snapshot(); system={'paused':db.state('paused')=='1','safe_mode':db.state('safe_mode')=='1','emergency_stop':db.state('emergency_stop')=='1'}
    return {'ok':not system['safe_mode'] and not system['emergency_stop'],'mode':'PAPER','live_enabled':False,'system':system,'metrics':{'decisions':s['decisions']['total'],'trades':s['trades']['total'],'open_positions':s['positions']['open_positions'],'errors':s['events']['errors']}}
