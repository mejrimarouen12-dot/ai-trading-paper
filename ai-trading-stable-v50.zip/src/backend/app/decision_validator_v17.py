from dataclasses import dataclass
from typing import Any, Dict

@dataclass
class ValidationResult:
    valid: bool
    reason: str
    normalized: Dict[str, Any]

class DecisionValidatorV17:
    ALLOWED={"BUY","SELL","HOLD"}
    def validate(self, d: Dict[str, Any]) -> ValidationResult:
        if not isinstance(d,dict): return ValidationResult(False,"Decision must be an object",{})
        action=d.get("decision")
        if action not in self.ALLOWED: return ValidationResult(False,"Invalid decision",{})
        try: conf=float(d.get("confidence",0))
        except Exception: return ValidationResult(False,"Invalid confidence",{})
        if not 0 <= conf <= 1: return ValidationResult(False,"Confidence outside 0..1",{})
        if action=="HOLD": return ValidationResult(True,"Valid HOLD",{"decision":"HOLD","confidence":conf})
        required=("entry","stop_loss","take_profit","thesis","invalidation_condition")
        if any(k not in d for k in required): return ValidationResult(False,"Missing required trade fields",{})
        try:
            entry=float(d["entry"]); sl=float(d["stop_loss"]); tp=float(d["take_profit"])
        except Exception: return ValidationResult(False,"Invalid trade prices",{})
        if min(entry,sl,tp)<=0: return ValidationResult(False,"Trade prices must be positive",{})
        if action=="BUY" and not (sl < entry < tp): return ValidationResult(False,"BUY price geometry invalid",{})
        if action=="SELL" and not (tp < entry < sl): return ValidationResult(False,"SELL price geometry invalid",{})
        rr=abs(tp-entry)/abs(entry-sl)
        if rr < 1.0: return ValidationResult(False,"Risk/reward below 1.0",{})
        return ValidationResult(True,"Valid executable decision",{**d,"decision":action,"confidence":conf,"entry":entry,"stop_loss":sl,"take_profit":tp,"risk_reward":rr})
