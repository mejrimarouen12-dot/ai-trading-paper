from dataclasses import dataclass
from datetime import datetime, timezone
from . import db, config
from .paper import open_positions
from .analytics import snapshot

@dataclass
class RiskDecision:
    approved: bool
    reason: str
    quantity: float = 0.0
    daily_loss_pct: float = 0.0
    drawdown_pct: float = 0.0
    risk_amount: float = 0.0

class RiskGuard:
    """Independent pre-order guard. It can only block a paper order; it never enables live trading."""
    MAX_DRAWDOWN_PCT = float(__import__('os').getenv('MAX_DRAWDOWN_PCT', '0.05'))
    MAX_NOTIONAL_PCT = float(__import__('os').getenv('MAX_NOTIONAL_PCT', '0.20'))

    def _day_start(self):
        today = datetime.now(timezone.utc).date().isoformat()
        stored = db.state('risk_day')
        if stored != today:
            current = snapshot()['equity']
            db.set_state('risk_day', today)
            db.set_state('risk_day_start_equity', current)
            return current
        return float(db.state('risk_day_start_equity') or snapshot()['equity'])

    def daily_loss_pct(self):
        start = self._day_start()
        c = db.conn()
        row = c.execute("SELECT COALESCE(SUM(pnl),0) pnl FROM trades WHERE created_at >= ?", (datetime.now(timezone.utc).date().isoformat(),)).fetchone()
        c.close()
        pnl = float(row['pnl'] or 0)
        loss = max(0.0, -pnl)
        return (loss / start) if start > 0 else 1.0

    def drawdown_pct(self):
        current = snapshot()['equity']
        c = db.conn()
        row = c.execute('SELECT MAX(equity) peak FROM equity').fetchone()
        c.close()
        peak = max(float(row['peak'] or config.STARTING_BALANCE), current)
        return max(0.0, (peak-current)/peak) if peak > 0 else 1.0

    def evaluate(self, decision, cash_value=None):
        # HOLD is rejected before any database-dependent risk bookkeeping so the guard
        # remains compatible with isolated unit calls before DB initialization.
        if decision.get('decision') not in ('BUY','SELL'):
            return RiskDecision(False, 'No executable decision')
        cash_value = float(cash_value if cash_value is not None else db.state('cash') or 0)
        daily = self.daily_loss_pct()
        dd = self.drawdown_pct()
        if daily >= config.MAX_DAILY_LOSS:
            db.set_state('paused','1'); db.event('WARN','DAILY_LOSS_LIMIT',f'{daily:.4f}')
            return RiskDecision(False, 'Daily loss limit reached', daily_loss_pct=daily, drawdown_pct=dd)
        if dd >= self.MAX_DRAWDOWN_PCT:
            db.set_state('safe_mode','1'); db.event('ERROR','MAX_DRAWDOWN_LIMIT',f'{dd:.4f}')
            return RiskDecision(False, 'Maximum drawdown limit reached', daily_loss_pct=daily, drawdown_pct=dd)
        if len(open_positions()) >= config.MAX_OPEN_POSITIONS:
            return RiskDecision(False, 'Max open positions reached', daily_loss_pct=daily, drawdown_pct=dd)
        try:
            entry=float(decision['entry']); stop=float(decision['stop_loss']); target=float(decision['take_profit'])
        except (KeyError, TypeError, ValueError):
            return RiskDecision(False, 'Invalid protective levels', daily_loss_pct=daily, drawdown_pct=dd)
        if min(entry,stop,target) <= 0 or entry == stop:
            return RiskDecision(False, 'Invalid protective levels', daily_loss_pct=daily, drawdown_pct=dd)
        risk_per_unit=abs(entry-stop)
        rr=abs(target-entry)/risk_per_unit
        if rr < 1.8:
            return RiskDecision(False, 'Risk/reward below minimum', daily_loss_pct=daily, drawdown_pct=dd)
        if float(decision.get('confidence',0)) < 0.65:
            return RiskDecision(False, 'Confidence below threshold', daily_loss_pct=daily, drawdown_pct=dd)
        risk_amount=cash_value*config.RISK_PER_TRADE
        qty=risk_amount/risk_per_unit
        max_qty=(cash_value*self.MAX_NOTIONAL_PCT)/entry if entry else 0
        qty=min(qty,max_qty)
        if qty <= 0 or entry*qty > cash_value*self.MAX_NOTIONAL_PCT:
            return RiskDecision(False, 'Position sizing limit', daily_loss_pct=daily, drawdown_pct=dd)
        return RiskDecision(True, 'Approved', qty, daily, dd, risk_amount)
