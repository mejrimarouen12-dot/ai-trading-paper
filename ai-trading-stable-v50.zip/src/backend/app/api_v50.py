from fastapi import APIRouter
from .release_v50 import ReleaseV50
from .watchdog_v35 import PaperWatchdogV35

router = APIRouter(prefix="/v50", tags=["v50-stable-paper"])

@router.get("/manifest")
def manifest():
    return ReleaseV50.manifest()

@router.get("/evaluation")
def evaluation():
    return ReleaseV50.evaluation()

@router.get("/safety")
def safety():
    return PaperWatchdogV35().inspect().__dict__
