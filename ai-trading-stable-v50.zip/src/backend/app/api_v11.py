from fastapi import APIRouter
from .scheduler_v11 import PaperScheduler
from .reports_v11 import daily_report, weekly_report, recovery_status
from . import db

router=APIRouter(prefix='/v11',tags=['v11-operations'])
_scheduler=PaperScheduler()

@router.get('/scheduler')
def scheduler(): return _scheduler.status().__dict__

@router.post('/scheduler/run-once')
def run_once():
    r=_scheduler.run_once(); return {'report':r.__dict__ if r else None,'scheduler':_scheduler.status().__dict__}

@router.post('/scheduler/start')
def start(): return {'started':_scheduler.start(),'scheduler':_scheduler.status().__dict__}

@router.post('/scheduler/stop')
def stop(): return {'stopped':_scheduler.stop(),'scheduler':_scheduler.status().__dict__}

@router.get('/report/daily')
def daily(): return daily_report()

@router.get('/report/weekly')
def weekly(): return weekly_report()

@router.get('/recovery')
def recovery(): return recovery_status()
