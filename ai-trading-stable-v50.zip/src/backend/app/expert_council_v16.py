from dataclasses import dataclass
from typing import Dict

@dataclass
class AnalystView:
    name: str
    action: str
    confidence: float
    reason: str

@dataclass
class CouncilResult:
    decision: str
    confidence: float
    consensus: float
    contrarian_risk: str
    rationale: str
    analysts: Dict[str, AnalystView]

class ExpertCouncil:
    """Deterministic multi-analyst council. It advises; Risk Guard remains authoritative."""
    WEIGHTS = {"market": .25, "technical": .30, "risk": .25, "contrarian": .20}
    MIN_CONSENSUS = .60

    def _market(self, s):
        if s.regime == 'TREND_UP': return AnalystView('market','BUY',.78,'Market regime is upward')
        if s.regime == 'TREND_DOWN': return AnalystView('market','SELL',.78,'Market regime is downward')
        return AnalystView('market','HOLD',.60,'Market regime is non-directional')

    def _technical(self, s):
        if s.ema20 > s.ema50 and s.rsi >= 55 and s.volume_ratio >= 1.0:
            return AnalystView('technical','BUY',.80,'Trend, momentum and volume align')
        if s.ema20 < s.ema50 and s.rsi <= 45 and s.volume_ratio >= 1.0:
            return AnalystView('technical','SELL',.80,'Trend, momentum and volume align')
        return AnalystView('technical','HOLD',.58,'Technical factors are mixed')

    def _risk(self, s):
        if not s.quality or s.atr <= 0 or s.price <= 0:
            return AnalystView('risk','HOLD',.95,'Market data fails risk-quality gate')
        atr_pct=s.atr/s.price
        if atr_pct > .04:
            return AnalystView('risk','HOLD',.88,'Volatility is too high for a clean setup')
        return AnalystView('risk','NEUTRAL',.72,'No standalone risk veto; sizing remains with Risk Guard')

    def _contrarian(self, s, proposed):
        if proposed not in ('BUY','SELL'):
            return AnalystView('contrarian','HOLD',.70,'No trade thesis to challenge')
        stretched=(proposed=='BUY' and s.rsi>=70) or (proposed=='SELL' and s.rsi<=30)
        if stretched:
            return AnalystView('contrarian','HOLD',.86,'Momentum is potentially stretched')
        return AnalystView('contrarian',proposed,.68,'No strong reversal signal detected')

    def evaluate(self, s, proposed=None):
        if not s.quality:
            a={'market':self._market(s),'technical':self._technical(s),'risk':self._risk(s),'contrarian':self._contrarian(s,'HOLD')}
            return CouncilResult('HOLD',.95,1.0,'High: invalid market data','Market quality failed',a)
        a0=self._market(s); a1=self._technical(s)
        base=proposed if proposed in ('BUY','SELL') else ('BUY' if a0.action=='BUY' and a1.action=='BUY' else 'SELL' if a0.action=='SELL' and a1.action=='SELL' else 'HOLD')
        a2=self._risk(s); a3=self._contrarian(s,base)
        a={'market':a0,'technical':a1,'risk':a2,'contrarian':a3}
        scores={k:(1 if v.action==base else 0 if v.action=='NEUTRAL' else -1) for k,v in a.items()}
        positive=sum(self.WEIGHTS[k] for k,v in a.items() if v.action==base)
        opposing=sum(self.WEIGHTS[k] for k,v in a.items() if v.action not in (base,'NEUTRAL'))
        consensus=max(0.0,min(1.0,positive-opposing+0.5))
        veto=a2.action=='HOLD' and a2.confidence>=.85
        if base not in ('BUY','SELL') or consensus < self.MIN_CONSENSUS or veto or a3.action=='HOLD':
            decision='HOLD'
        else:
            decision=base
        confidence=round(sum(self.WEIGHTS[k]*a[k].confidence for k in a),4)
        risk='High' if a3.action=='HOLD' and base in ('BUY','SELL') else 'Normal'
        rationale='Council consensus supports '+decision if decision!='HOLD' else 'Council did not reach a sufficiently aligned executable consensus'
        return CouncilResult(decision,confidence,round(consensus,4),risk,rationale,a)
