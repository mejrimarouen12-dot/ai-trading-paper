from fastapi import APIRouter
from .expert_council_v16 import ExpertCouncil
from .market import MarketEngine
from . import db
router=APIRouter(prefix='/v16',tags=['v16-expert-council'])

@router.get('/council')
def council(symbol: str='BTC/USDT'):
    s=MarketEngine().snapshot(symbol)
    r=ExpertCouncil().evaluate(s)
    return {'mode':'PAPER','live_orders':False,'symbol':symbol,'decision':r.decision,
            'confidence':r.confidence,'consensus':r.consensus,'contrarian_risk':r.contrarian_risk,
            'rationale':r.rationale,'analysts':{k:v.__dict__ for k,v in r.analysts.items()},
            'risk_guard_authority':True,'safe_mode':db.state('safe_mode')=='1'}
