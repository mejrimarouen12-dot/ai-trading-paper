from dataclasses import dataclass

@dataclass
class RegimeResult:
    regime:str
    confidence:float
    trade_allowed:bool
    reason:str

class MarketRegimeEngineV18:
    def classify(self,s):
        if not s.quality or s.price<=0: return RegimeResult("UNKNOWN",1.0,False,"Invalid market data")
        atr_pct=s.atr/s.price
        if atr_pct>0.04: return RegimeResult("HIGH_VOLATILITY",0.92,False,"ATR volatility above safety threshold")
        spread=abs(s.ema20-s.ema50)/s.price
        if spread<0.0015 and 45<=s.rsi<=55: return RegimeResult("RANGING",0.78,False,"Low directional separation")
        if spread>=0.003:
            return RegimeResult("TRENDING_UP",0.82,True,"EMA structure supports upward trend") if s.ema20>s.ema50 else RegimeResult("TRENDING_DOWN",0.82,True,"EMA structure supports downward trend")
        return RegimeResult("TRANSITION",0.65,False,"Market structure is transitioning")
