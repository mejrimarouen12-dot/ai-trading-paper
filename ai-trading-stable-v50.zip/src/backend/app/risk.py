from . import db
from .risk_guard_v12 import RiskGuard

def approve(decision, cash, open_positions):
    if decision.get('decision') == 'HOLD':
        return False, 'HOLD'
    # Preserve the lightweight approve() contract for callers that invoke it before app startup.
    db.init_db()
    result=RiskGuard().evaluate(decision, cash)
    if not result.approved:
        return False, result.reason
    return True, result.quantity
