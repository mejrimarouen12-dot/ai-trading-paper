from dataclasses import dataclass
from datetime import datetime, timezone
import os

@dataclass(frozen=True)
class ReleaseCheck:
    name: str
    ok: bool
    detail: str

class ReleasePreflight:
    VERSION = "33.0"
    MODE = "PAPER"

    @classmethod
    def run(cls):
        checks = []
        checks.append(ReleaseCheck("paper_mode", os.getenv("TRADING_MODE", "PAPER").upper() == "PAPER", "LIVE is not an allowed release mode"))
        checks.append(ReleaseCheck("live_flag", os.getenv("LIVE_TRADING", "false").lower() != "true", "LIVE_TRADING must not be true"))
        checks.append(ReleaseCheck("withdrawals", os.getenv("ALLOW_WITHDRAWALS", "false").lower() != "true", "withdrawal capability must remain disabled"))
        checks.append(ReleaseCheck("api_keys", not any(k in os.environ for k in ("BINANCE_SECRET_KEY", "EXCHANGE_SECRET_KEY")), "exchange secret keys are not required for paper release"))
        checks.append(ReleaseCheck("database_path", bool(os.getenv("DB_PATH", "trading.db")), "database path is defined"))
        return checks

    @classmethod
    def manifest(cls):
        checks = cls.run()
        return {
            "release": "AI Trading Paper Release",
            "version": cls.VERSION,
            "mode": cls.MODE,
            "live_enabled": False,
            "withdrawals_enabled": False,
            "certified_at": datetime.now(timezone.utc).isoformat(),
            "checks": [{"name": c.name, "ok": c.ok, "detail": c.detail} for c in checks],
            "ready": all(c.ok for c in checks),
        }
