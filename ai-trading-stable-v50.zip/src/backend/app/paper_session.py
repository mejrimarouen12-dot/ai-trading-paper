from dataclasses import dataclass
from datetime import datetime, timezone
from . import db, config
from .paper_feed import PaperFeed
from .expert import decide
from .paper import execute, mark_and_exit
from .intelligence import record_decision_audit

@dataclass
class CycleReport:
    status: str
    market_source: str
    symbols_checked: int
    decisions: int
    executed: int
    rejected: int
    closed: int
    error: str = ""

class PaperSession:
    def __init__(self, feed=None):
        self.feed=feed or PaperFeed(use_real=True)

    def run_cycle(self):
        if any(db.state(k)=='1' for k in ('paused','safe_mode','emergency_stop')):
            return CycleReport('BLOCKED','real_public',0,0,0,0,0,'safety state active')
        prices={}; executed=rejected=decisions=0
        try:
            for symbol in config.SYMBOLS:
                s=self.feed.snapshot(symbol,'5m'); prices[symbol]=s.price
                d=decide(s); decisions+=1
                c=db.conn(); c.execute('INSERT INTO decisions(symbol,decision,confidence,regime,entry,stop_loss,take_profit,thesis,invalidation,contrarian_risk,reason,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',(symbol,d.get('decision'),d.get('confidence',0),d.get('regime'),d.get('entry'),d.get('stop_loss'),d.get('take_profit'),d.get('thesis'),d.get('invalidation'),d.get('contrarian_risk'),d.get('reason'),db.now())); c.commit(); c.close()
                if d.get('decision') in ('BUY','SELL'):
                    ok,msg=execute(symbol,d)
                    executed += int(ok); rejected += int(not ok)
                    record_decision_audit(symbol,d,{'price':s.price,'regime':s.regime},'EXECUTED' if ok else 'REJECTED')
                else: record_decision_audit(symbol,d,{'price':s.price,'regime':s.regime},'HOLD')
            closed=mark_and_exit(prices)
            db.event('INFO','PAPER_CYCLE',f'executed={executed},rejected={rejected},closed={len(closed)}')
            return CycleReport('OK','real_public',len(config.SYMBOLS),decisions,executed,rejected,len(closed))
        except Exception as e:
            db.set_state('safe_mode','1'); db.event('ERROR','MARKET_CYCLE_FAILURE',str(e))
            return CycleReport('SAFE_MODE','real_public',len(prices),decisions,executed,rejected,0,str(e))
