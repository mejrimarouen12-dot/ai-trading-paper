from fastapi import APIRouter
from .risk_guard_v13 import AdvancedRiskGuard
from . import db
router=APIRouter(prefix='/v13',tags=['v13-advanced-risk'])
@router.get('/risk')
def risk():
    g=AdvancedRiskGuard()
    return {'mode':'PAPER','live_orders':False,'trades_today':g.trades_today(),'max_trades_per_day':g.MAX_TRADES_PER_DAY,'consecutive_losses':g.consecutive_losses(),'cooldown_minutes':g.LOSS_COOLDOWN_MIN,'paused':db.state('paused')=='1','safe_mode':db.state('safe_mode')=='1','emergency_stop':db.state('emergency_stop')=='1'}
