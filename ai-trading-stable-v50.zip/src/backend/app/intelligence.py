import json
from . import db


def record_decision_audit(symbol, decision, context, verdict):
    c=db.conn()
    c.execute('''CREATE TABLE IF NOT EXISTS decision_audits(
      id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT, decision_id INTEGER,
      context_json TEXT, verdict TEXT, created_at TEXT)''')
    row=c.execute('SELECT id FROM decisions WHERE symbol=? ORDER BY id DESC LIMIT 1',(symbol,)).fetchone()
    did=row['id'] if row else None
    c.execute('INSERT INTO decision_audits(symbol,decision_id,context_json,verdict,created_at) VALUES(?,?,?,?,?)',
              (symbol,did,json.dumps(context,sort_keys=True,default=str),verdict,db.now()))
    c.commit(); c.close()
    return did


def replay_decision(decision_id):
    c=db.conn()
    d=c.execute('SELECT * FROM decisions WHERE id=?',(decision_id,)).fetchone()
    a=c.execute('SELECT * FROM decision_audits WHERE decision_id=? ORDER BY id DESC LIMIT 1',(decision_id,)).fetchone()
    c.close()
    if not d:
        return None
    return {'decision':dict(d),'audit':dict(a) if a else None}


def trade_memory(limit=50):
    c=db.conn()
    rows=c.execute('SELECT * FROM trades ORDER BY id DESC LIMIT ?',(limit,)).fetchall()
    c.close()
    trades=[dict(r) for r in rows]
    wins=[t for t in trades if (t.get('pnl') or 0)>0]
    losses=[t for t in trades if (t.get('pnl') or 0)<0]
    gross_win=sum(t.get('pnl') or 0 for t in wins)
    gross_loss=abs(sum(t.get('pnl') or 0 for t in losses))
    return {'trades':trades,'count':len(trades),'wins':len(wins),'losses':len(losses),
            'win_rate':len(wins)/len(trades) if trades else 0,
            'profit_factor':gross_win/gross_loss if gross_loss else None,
            'net_pnl':sum(t.get('pnl') or 0 for t in trades)}


def lessons(limit=100):
    c=db.conn()
    rows=c.execute('''SELECT d.symbol,d.decision,d.regime,d.confidence,d.contrarian_risk,t.pnl,t.exit_reason
                      FROM decisions d JOIN trades t ON t.symbol=d.symbol
                      ORDER BY t.id DESC LIMIT ?''',(limit,)).fetchall()
    c.close()
    out=[]
    for r in rows:
        r=dict(r)
        pnl=r.get('pnl') or 0
        if pnl>0: lesson='Setup worked; preserve the original thesis and risk discipline.'
        elif pnl<0: lesson='Review invalidation timing, regime alignment, and contrarian risk before repeating.'
        else: lesson='Neutral outcome; no strategy change from one trade.'
        r['lesson']=lesson; out.append(r)
    return out
