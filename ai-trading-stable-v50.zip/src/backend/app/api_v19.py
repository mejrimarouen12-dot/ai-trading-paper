from fastapi import APIRouter
from .adaptive_strategy_v19 import AdaptiveStrategyEngineV19

router = APIRouter(prefix='/v19', tags=['v19-adaptive'])

@router.get('/policy')
def policy(regime: str = 'TRENDING_UP'):
    p = AdaptiveStrategyEngineV19().policy(regime)
    return {'mode':'PAPER','live_orders':False,'regime':p.regime,'style':p.style,'min_quality':p.min_quality,'min_confidence':p.min_confidence,'min_rr':p.min_rr,'allow_entries':p.allow_entries,'allowed_actions':p.allowed_actions,'reason':p.reason}
