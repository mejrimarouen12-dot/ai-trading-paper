from . import db, config

def cash(): return float(db.state('cash'))

def open_positions():
    c=db.conn(); rows=c.execute("SELECT * FROM positions WHERE status='OPEN'").fetchall(); c.close(); return [dict(r) for r in rows]

def execute(symbol, decision):
    from .risk import approve
    ok,size=approve(decision,cash(),open_positions())
    if not ok:
        db.event('WARN','RISK_REJECT',str(size))
        return False,size
    entry=float(decision['entry']); fee=entry*size*config.FEE_RATE
    if cash() < fee: return False,'Insufficient paper cash for fee'
    db.set_state('cash',cash()-fee)
    c=db.conn()
    c.execute("INSERT INTO positions(symbol,side,entry_price,quantity,stop_loss,take_profit,status,opened_at) VALUES(?,?,?,?,?,?,?,?)",
              (symbol,decision['decision'],entry,size,decision['stop_loss'],decision['take_profit'],'OPEN',db.now()))
    c.commit(); c.close(); return True,size

def mark_and_exit(prices):
    """Apply SL/TP to open paper positions. Returns closed trades."""
    closed=[]
    for p in open_positions():
        price=float(prices.get(p['symbol'],0)); side=p['side']; exit_reason=None
        if side=='BUY':
            if price <= p['stop_loss']: exit_reason='STOP_LOSS'
            elif price >= p['take_profit']: exit_reason='TAKE_PROFIT'
            pnl=(price-p['entry_price'])*p['quantity']
        else:
            if price >= p['stop_loss']: exit_reason='STOP_LOSS'
            elif price <= p['take_profit']: exit_reason='TAKE_PROFIT'
            pnl=(p['entry_price']-price)*p['quantity']
        if not exit_reason: continue
        fee=(float(p['entry_price'])*p['quantity']+price*p['quantity'])*config.FEE_RATE
        net=pnl-fee
        db.set_state('cash',cash()+net)
        c=db.conn(); c.execute("UPDATE positions SET status='CLOSED',closed_at=? WHERE id=?",(db.now(),p['id']))
        c.execute("INSERT INTO trades(position_id,symbol,side,entry_price,exit_price,quantity,fees,pnl,exit_reason,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                  (p['id'],p['symbol'],side,p['entry_price'],price,p['quantity'],fee,net,exit_reason,db.now()))
        c.commit(); c.close(); closed.append({'symbol':p['symbol'],'reason':exit_reason,'pnl':net})
    return closed
