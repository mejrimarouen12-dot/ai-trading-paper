from __future__ import annotations
import json, os, urllib.request

class AIProvider:
    """Optional generic JSON AI adapter. Disabled unless AI_API_URL and AI_API_KEY are set."""
    def __init__(self):
        self.url=os.getenv("AI_API_URL",""); self.key=os.getenv("AI_API_KEY","")
    @property
    def enabled(self): return bool(self.url and self.key)
    def decide(self, context:dict)->dict|None:
        if not self.enabled:return None
        body=json.dumps({"system":"You are a conservative trading analyst. Return JSON only: decision BUY/SELL/HOLD, confidence 0..1, thesis, invalidation, contrarian_risk. Never invent missing data.","input":context}).encode()
        req=urllib.request.Request(self.url,data=body,headers={"Content-Type":"application/json","Authorization":f"Bearer {self.key}"},method="POST")
        with urllib.request.urlopen(req,timeout=15) as r: data=json.loads(r.read().decode())
        return data if isinstance(data,dict) else None
