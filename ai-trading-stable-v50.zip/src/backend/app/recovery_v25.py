import json, os, tempfile
from dataclasses import dataclass
@dataclass(frozen=True)
class ReconciliationResult:
    ok: bool
    issues: list[str]
    recovered_orders: int
class RecoveryStoreV25:
    def __init__(self,path='trading_recovery_v25.json'): self.path=path
    def save(self,payload):
        d=os.path.dirname(os.path.abspath(self.path)) or '.'; os.makedirs(d,exist_ok=True)
        fd,tmp=tempfile.mkstemp(prefix='.recovery-',dir=d,text=True)
        try:
            with os.fdopen(fd,'w',encoding='utf-8') as f: json.dump(payload,f,separators=(',',':'),sort_keys=True); f.flush(); os.fsync(f.fileno())
            os.replace(tmp,self.path)
        finally:
            if os.path.exists(tmp): os.unlink(tmp)
    def load(self):
        if not os.path.exists(self.path): return None
        with open(self.path,encoding='utf-8') as f: return json.load(f)
    @staticmethod
    def reconcile(p):
        issues=[]; orders=p.get('orders',{}); states=p.get('states',{}); filled=p.get('filled',{})
        for oid,o in orders.items():
            q=float(o.get('quantity',0)); f=float(filled.get(oid,0)); st=states.get(oid)
            if q<=0: issues.append(f'{oid}:INVALID_QUANTITY')
            if f<0 or f>q+1e-12: issues.append(f'{oid}:FILL_OUT_OF_RANGE')
            if st=='FILLED' and abs(f-q)>1e-12: issues.append(f'{oid}:FILLED_STATE_MISMATCH')
            if st=='PARTIALLY_FILLED' and not (0<f<q): issues.append(f'{oid}:PARTIAL_STATE_MISMATCH')
            if st in ('CREATED','VALIDATED','SUBMITTED') and f>0: issues.append(f'{oid}:NON_FILL_STATE_HAS_FILL')
        return ReconciliationResult(not issues,issues,sum(1 for s in states.values() if s in ('SUBMITTED','PARTIALLY_FILLED','CANCEL_PENDING')))
