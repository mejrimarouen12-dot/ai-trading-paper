from .live_market import PublicMarketAdapter, MarketDataError
from .market import MarketEngine

class PaperFeed:
    """Real-data read-only feed with deterministic simulator fallback disabled by default."""
    def __init__(self, use_real=True):
        self.use_real=use_real
        self.real=PublicMarketAdapter()
        self.sim=MarketEngine()

    def snapshot(self,symbol,timeframe="5m"):
        if self.use_real:
            return self.real.snapshot(symbol,timeframe)
        return self.sim.snapshot(symbol)
