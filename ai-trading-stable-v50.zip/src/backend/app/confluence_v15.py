from dataclasses import dataclass
from .multitimeframe import score

FRAMES = ("5m", "15m", "1h", "4h")
WEIGHTS = {"5m":0.15, "15m":0.20, "1h":0.30, "4h":0.35}

@dataclass
class ConfluenceResult:
    approved: bool
    action: str
    score: float
    agreement: float
    reason: str
    frames: dict

class MultiTimeframeConfluence:
    """Deterministic MTF gate. It does not execute orders and never overrides Risk Guard."""
    MIN_CONFLUENCE = 0.65
    MIN_DIRECTIONAL_AGREEMENT = 0.75

    def evaluate(self, frames: dict, proposed_action: str) -> ConfluenceResult:
        if proposed_action not in ("BUY", "SELL"):
            return ConfluenceResult(False, proposed_action, 0.0, 0.0, "No executable action", {})
        rows = {f: score(frames[f]) for f in FRAMES if f in frames}
        if len(rows) != 4 or any(r.get("regime") == "UNKNOWN" for r in rows.values()):
            return ConfluenceResult(False, proposed_action, 0.0, 0.0, "Incomplete multi-timeframe data", rows)

        target = 1 if proposed_action == "BUY" else -1
        weighted = sum(WEIGHTS[f] * max(-1.0, min(1.0, float(rows[f].get("bias",0)))) for f in FRAMES)
        agreement = sum(WEIGHTS[f] for f in FRAMES if (rows[f].get("bias",0) * target) > 0)
        score_value = max(0.0, min(1.0, (weighted * target + 1.0) / 2.0))
        # Require higher-timeframe alignment: 1h and 4h must agree with the proposal.
        higher_ok = all((rows[f].get("bias",0) * target) > 0 for f in ("1h", "4h"))
        approved = score_value >= self.MIN_CONFLUENCE and agreement >= self.MIN_DIRECTIONAL_AGREEMENT and higher_ok
        if not higher_ok:
            reason = "Higher-timeframe conflict"
        elif agreement < self.MIN_DIRECTIONAL_AGREEMENT:
            reason = "Insufficient timeframe agreement"
        elif score_value < self.MIN_CONFLUENCE:
            reason = "Confluence score below threshold"
        else:
            reason = "Multi-timeframe confluence approved"
        return ConfluenceResult(approved, proposed_action, round(score_value,4), round(agreement,4), reason, rows)
