from dataclasses import dataclass
from typing import Any

@dataclass
class ReconciliationResult:
    ok: bool
    expected_equity: float
    observed_equity: float
    delta: float
    issues: list[str]

class IntegrityEngine:
    def reconcile(self, *, cash: float, positions: list[dict[str, Any]], prices: dict[str, float], recorded_equity: float, tolerance: float = 1e-6) -> ReconciliationResult:
        expected = float(cash)
        issues: list[str] = []
        for p in positions:
            symbol = p.get("symbol") or p.get("asset")
            qty = float(p.get("quantity", 0))
            entry = float(p.get("entry_price", 0))
            price = prices.get(symbol)
            if price is None:
                issues.append(f"missing_price:{symbol}")
                continue
            if qty < 0:
                issues.append(f"negative_quantity:{symbol}")
            expected += qty * float(price)
            if entry <= 0:
                issues.append(f"invalid_entry:{symbol}")
        delta = expected - float(recorded_equity)
        ok = abs(delta) <= tolerance and not issues
        return ReconciliationResult(ok, expected, float(recorded_equity), delta, issues)

    def validate_order(self, *, order_id: str, symbol: str, side: str, quantity: float, price: float) -> list[str]:
        issues=[]
        if not order_id: issues.append("missing_order_id")
        if not symbol: issues.append("missing_symbol")
        if side not in {"BUY", "SELL"}: issues.append("invalid_side")
        if quantity <= 0: issues.append("invalid_quantity")
        if price <= 0: issues.append("invalid_price")
        return issues
