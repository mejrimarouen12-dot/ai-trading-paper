import os

MODE = os.getenv("MODE", "PAPER").upper()
LIVE_TRADING = False
STARTING_BALANCE = float(os.getenv("PAPER_BALANCE", "10000"))
RISK_PER_TRADE = float(os.getenv("RISK_PER_TRADE", "0.005"))
MAX_DAILY_LOSS = float(os.getenv("MAX_DAILY_LOSS", "0.02"))
MAX_OPEN_POSITIONS = int(os.getenv("MAX_OPEN_POSITIONS", "2"))
SYMBOLS = ["BTC/USDT", "ETH/USDT", "SOL/USDT"]
TIMEFRAMES = ["5m", "15m", "1h", "4h"]
FEE_RATE = float(os.getenv("PAPER_FEE_RATE", "0.0004"))
SLIPPAGE_BPS = float(os.getenv("PAPER_SLIPPAGE_BPS", "3"))

if MODE != "PAPER" or LIVE_TRADING:
    raise RuntimeError("This build is PAPER-only. Live trading is intentionally disabled.")
