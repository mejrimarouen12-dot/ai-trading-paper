import time
from . import db
from .health import heartbeat, snapshot
from .alerts import critical

MAX_ERRORS = 3

def supervise_once():
    heartbeat()
    h = snapshot()
    errors = int(db.state('worker_consecutive_errors') or 0)
    if errors >= MAX_ERRORS:
        critical('WORKER_FAILURE', f'worker has {errors} consecutive errors; entering safe mode')
        return False
    return True

def record_success():
    db.set_state('worker_consecutive_errors','0')

def record_failure(exc):
    n = int(db.state('worker_consecutive_errors') or 0) + 1
    db.set_state('worker_consecutive_errors', str(n))
    db.event('ERROR','WORKER_FAILURE',str(exc))
    if n >= MAX_ERRORS:
        critical('WORKER_FAILURE', str(exc))
