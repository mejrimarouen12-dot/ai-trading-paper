import time
from .engine import cycle
from . import db
from .supervisor import supervise_once, record_success, record_failure

INTERVAL = 15

def main():
    db.init_db()
    while True:
        try:
            if supervise_once():
                cycle()
                record_success()
        except Exception as e:
            record_failure(e)
        time.sleep(INTERVAL)

if __name__=='__main__': main()
