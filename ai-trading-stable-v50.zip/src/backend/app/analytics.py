from . import db, config
from .paper import open_positions

START = config.STARTING_BALANCE

def snapshot(prices=None):
    prices = prices or {}
    cash = float(db.state('cash') or 0)
    openp = open_positions()
    unrealized = 0.0
    for p in openp:
        price = float(prices.get(p['symbol'], p['entry_price']))
        qty = float(p['quantity']); entry = float(p['entry_price'])
        unrealized += (price-entry)*qty if p['side']=='BUY' else (entry-price)*qty
    c=db.conn()
    r=c.execute('SELECT COALESCE(SUM(pnl),0) pnl, COUNT(*) n, COALESCE(SUM(fees),0) fees FROM trades').fetchone()
    c.close()
    realized=float(r['pnl']); fees=float(r['fees'])
    equity=cash+unrealized
    return {'cash':cash,'equity':equity,'unrealized_pnl':unrealized,'realized_pnl':realized,'fees':fees,'open_positions':len(openp),'closed_trades':int(r['n'])}

def performance():
    c=db.conn()
    trades=c.execute('SELECT pnl, fees, exit_reason FROM trades ORDER BY id').fetchall()
    eq=c.execute('SELECT equity, created_at FROM equity ORDER BY id').fetchall()
    c.close()
    pnls=[float(x['pnl']) for x in trades]
    wins=[x for x in pnls if x>0]; losses=[x for x in pnls if x<0]
    gross_profit=sum(wins); gross_loss=abs(sum(losses))
    profit_factor=(gross_profit/gross_loss) if gross_loss else (None if not wins else float('inf'))
    win_rate=(len(wins)/len(pnls)*100) if pnls else 0.0
    equity_curve=[{'equity':float(x['equity']),'created_at':x['created_at']} for x in eq]
    peak=START; max_dd=0.0
    for x in equity_curve:
        peak=max(peak,x['equity']); max_dd=max(max_dd,(peak-x['equity'])/peak if peak else 0)
    return {'starting_balance':START,'trade_count':len(pnls),'win_rate_pct':win_rate,'gross_profit':gross_profit,'gross_loss':gross_loss,'profit_factor':profit_factor,'avg_trade':sum(pnls)/len(pnls) if pnls else 0.0,'net_pnl':sum(pnls),'max_drawdown_pct':max_dd*100,'equity_curve':equity_curve[-300:]}

def record_equity(prices=None):
    s=snapshot(prices)
    c=db.conn(); c.execute('INSERT INTO equity(balance,equity,created_at) VALUES(?,?,?)',(s['cash'],s['equity'],db.now())); c.commit(); c.close()
    return s
