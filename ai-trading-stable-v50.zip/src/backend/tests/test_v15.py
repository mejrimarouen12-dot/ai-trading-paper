from app.confluence_v15 import MultiTimeframeConfluence
from app.market import MarketEngine


def frame_set(direction=1):
    m=MarketEngine()
    out={f:m.candles('BTC/USDT',250) for f in ('5m','15m','1h','4h')}
    # Build deterministic directional fixtures with enough candles for indicators.
    if direction < 0:
        for f, candles in out.items():
            base=10000
            for i,c in enumerate(candles):
                c.close=base*(1-0.0008*i)
                c.open=c.close*(1+0.0002)
                c.high=max(c.open,c.close)*1.0005
                c.low=min(c.open,c.close)*0.9995
    else:
        for f, candles in out.items():
            base=10000
            for i,c in enumerate(candles):
                c.close=base*(1+0.0008*i)
                c.open=c.close*(1-0.0002)
                c.high=max(c.open,c.close)*1.0005
                c.low=min(c.open,c.close)*0.9995
    return out


def test_bullish_confluence_approved():
    r=MultiTimeframeConfluence().evaluate(frame_set(1),'BUY')
    assert r.approved and r.agreement >= .75 and r.score >= .65

def test_bearish_confluence_approved():
    r=MultiTimeframeConfluence().evaluate(frame_set(-1),'SELL')
    assert r.approved and r.agreement >= .75

def test_conflicting_action_rejected():
    r=MultiTimeframeConfluence().evaluate(frame_set(1),'SELL')
    assert not r.approved and 'Higher-timeframe conflict' in r.reason

def test_missing_frame_rejected():
    frames=frame_set(1); frames.pop('4h')
    r=MultiTimeframeConfluence().evaluate(frames,'BUY')
    assert not r.approved and 'Incomplete' in r.reason

def test_hold_rejected():
    r=MultiTimeframeConfluence().evaluate(frame_set(1),'HOLD')
    assert not r.approved
