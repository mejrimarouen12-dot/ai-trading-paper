from app.execution_v24 import Order,OrderState
from app.execution_service_v24 import ExecutionServiceV24
def test_restart_recovery_and_reconciliation(tmp_path):
 p=str(tmp_path/'state.json'); s=ExecutionServiceV24(p); s.create_order(Order('R1','BTC/USDT','BUY',10,100)); s.transition('R1',OrderState.VALIDATED); s.transition('R1',OrderState.SUBMITTED); s.fill('R1',4)
 r=ExecutionServiceV24(p); assert r.machine.snapshot('R1')['filled_quantity']==4; assert r.machine.snapshot('R1')['state']=='PARTIALLY_FILLED'; assert r.reconciliation()['ok']; assert r.recover()['recovered_orders']==1
def test_reconciliation_catches_mismatch(tmp_path):
 p=str(tmp_path/'bad.json'); s=ExecutionServiceV24(p); s.store.save({'orders':{'R2':{'order_id':'R2','symbol':'ETH/USDT','side':'BUY','quantity':2,'price':100}},'states':{'R2':'FILLED'},'filled':{'R2':1}}); assert not ExecutionServiceV24(p).recover()['ok']
def test_terminal_order_survives_restart(tmp_path):
 p=str(tmp_path/'terminal.json'); s=ExecutionServiceV24(p); s.create_order(Order('R3','SOL/USDT','SELL',3,50)); s.transition('R3',OrderState.VALIDATED); s.transition('R3',OrderState.SUBMITTED); s.fill('R3',3); r=ExecutionServiceV24(p); assert r.machine.snapshot('R3')['state']=='FILLED'; assert r.reconciliation()['ok']
