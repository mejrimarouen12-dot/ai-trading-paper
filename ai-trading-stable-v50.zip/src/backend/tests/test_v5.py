from app.strategy_lab import REGISTRY, compare, regime_slices
from app.market import MarketEngine

def test_strategy_registry_is_manual_governed():
    assert len(REGISTRY)>=2
    assert all(s.version for s in REGISTRY)

def test_lab_outputs_and_regimes():
    c=MarketEngine().candles('BTC/USDT',180)
    result=compare(c)
    assert len(result['results'])==len(REGISTRY)
    assert result['promotion']=='MANUAL_ONLY'
    assert sum(regime_slices(c).values())==120
