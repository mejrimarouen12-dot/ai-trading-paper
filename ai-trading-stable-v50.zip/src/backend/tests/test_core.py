import os,sys,tempfile,unittest
sys.path.insert(0,os.path.join(os.path.dirname(__file__),'..'))

class CoreTests(unittest.TestCase):
    def test_backtest_returns_metrics(self):
        from app.backtest import run
        r=run('BTC/USDT',120,10000)
        self.assertIn('max_drawdown_pct',r); self.assertIn('trades',r); self.assertGreater(r['bars'],0)
    def test_safety_rejects_bad_rr(self):
        from app.risk import approve
        ok,msg=approve({'decision':'BUY','confidence':.9,'entry':100,'stop_loss':99,'take_profit':100.5},10000,[])
        self.assertFalse(ok); self.assertIn('Risk/reward',msg)
    def test_safety_rejects_hold(self):
        from app.risk import approve
        ok,msg=approve({'decision':'HOLD'},10000,[])
        self.assertFalse(ok); self.assertEqual(msg,'HOLD')

if __name__=='__main__': unittest.main()
