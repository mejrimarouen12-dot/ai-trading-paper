from datetime import datetime, timezone, timedelta
from app import db
from app.watchdog_v35 import PaperWatchdogV35

def setup_function():
    db.init_db()
    for k,v in {"paused":"0","safe_mode":"0","emergency_stop":"0","paper_runner_lock":"0","paper_runner_stop":"0","paper_runner_last_at":"","paper_runner_last_status":""}.items(): db.set_state(k,v)

def test_no_heartbeat_is_no_new_trade():
    r = PaperWatchdogV35().inspect()
    assert r.status == "NO_HEARTBEAT"
    assert r.healthy is False
    out = PaperWatchdogV35().enforce()
    assert out["action"] == "NO_NEW_TRADE"

def test_fresh_heartbeat_is_healthy():
    db.set_state("paper_runner_last_at", datetime.now(timezone.utc).isoformat())
    r = PaperWatchdogV35().inspect()
    assert r.status == "HEALTHY"
    assert r.healthy is True

def test_stale_heartbeat_enters_safe_mode():
    old = datetime.now(timezone.utc) - timedelta(seconds=120)
    db.set_state("paper_runner_last_at", old.isoformat())
    out = PaperWatchdogV35().enforce(stale_after_seconds=60)
    assert out["action"] == "SAFE_MODE"
    assert db.state("safe_mode") == "1"

def test_safety_state_has_priority():
    db.set_state("safe_mode", "1")
    db.set_state("paper_runner_last_at", datetime.now(timezone.utc).isoformat())
    r = PaperWatchdogV35().inspect()
    assert r.status == "SAFE_BLOCKED"
    assert r.healthy is False
