from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_security_is_paper_only():
    r=client.get('/v30/security'); assert r.status_code==200
    d=r.json(); assert d['mode']=='PAPER'; assert d['live_enabled'] is False; assert d['paper_only'] is True

def test_config_check():
    r=client.get('/v30/config-check'); assert r.status_code==200; assert r.json()['ok'] is True

def test_redaction():
    r=client.post('/v30/redact', json={'api_key':'secret123','nested':{'password':'abc'},'text':'token=xyz'}); assert r.status_code==200
    d=r.json(); assert d['api_key']=='[REDACTED]'; assert d['nested']['password']=='[REDACTED]'; assert '[REDACTED]' in d['text']
