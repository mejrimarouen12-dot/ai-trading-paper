from app.execution_v24 import Order, OrderState
from app.execution_service_v24 import ExecutionServiceV24

def test_order_lifecycle_and_partial_fill():
    s=ExecutionServiceV24(); o=Order('O1','BTC/USDT','BUY',10,100)
    assert s.create_order(o)==(True,'CREATED')
    assert s.transition('O1',OrderState.VALIDATED)[0]
    assert s.transition('O1',OrderState.SUBMITTED)[0]
    assert s.fill('O1',4)==(True,'PARTIALLY_FILLED')
    assert s.fill('O1',6)==(True,'FILLED')
    assert s.machine.snapshot('O1')['filled_quantity']==10

def test_duplicate_id_is_rejected_idempotently():
    s=ExecutionServiceV24(); o=Order('O2','BTC/USDT','BUY',1,100)
    assert s.create_order(o)[0]
    assert s.create_order(o)==(False,'DUPLICATE_ORDER_ID')

def test_invalid_transition_and_overfill_are_blocked():
    s=ExecutionServiceV24(); s.create_order(Order('O3','BTC/USDT','BUY',5,100))
    assert not s.fill('O3',1)[0]
    s.transition('O3',OrderState.VALIDATED); s.transition('O3',OrderState.SUBMITTED)
    assert s.fill('O3',6)==(False,'OVERFILL')

def test_audit_chain_is_tamper_evident():
    s=ExecutionServiceV24(); s.create_order(Order('O4','ETH/USDT','SELL',2,200)); s.transition('O4',OrderState.VALIDATED)
    assert s.audit.verify()
    s.audit.events[0]=type(s.audit.events[0])(**{**s.audit.export()[0], 'message':'tampered'})
    assert not s.audit.verify()

def test_recovery_marks_inflight_orders():
    s=ExecutionServiceV24(); s.create_order(Order('O5','SOL/USDT','BUY',1,50)); s.transition('O5',OrderState.VALIDATED); s.transition('O5',OrderState.SUBMITTED)
    assert s.recoverable('O5')
