from app import db
from app.analytics import snapshot, performance, record_equity

def reset():
    db.init_db(); db.set_state('cash','10000'); db.set_state('safe_mode','0'); db.set_state('paused','0'); db.set_state('emergency_stop','0')

def test_v10_dashboard_contract():
    reset()
    from app.api_v10 import dashboard
    x=dashboard(); assert x['mode']=='PAPER'; assert x['live_orders'] is False
    assert 'current' in x and 'performance' in x and 'safety' in x

def test_v10_equity_snapshot_and_record():
    reset(); s=snapshot(); assert s['equity']==10000
    r=record_equity(); assert r['equity']==10000

def test_v10_performance_metrics_empty_safe():
    reset(); p=performance(); assert p['trade_count']==0; assert p['win_rate_pct']==0; assert p['net_pnl']==0
