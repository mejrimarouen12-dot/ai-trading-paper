from app import db
from app.risk_guard_v13 import AdvancedRiskGuard

def reset():
    db.init_db(); c=db.conn(); c.execute('DELETE FROM trades'); c.execute('DELETE FROM equity'); c.execute('DELETE FROM positions'); c.commit(); c.close()
    for k,v in [('cash','10000'),('safe_mode','0'),('paused','0'),('emergency_stop','0'),('risk_day',''),('risk_day_start_equity','10000')]: db.set_state(k,v)

def decision(): return {'decision':'BUY','confidence':0.8,'entry':100.0,'stop_loss':95.0,'take_profit':110.0}

def add_trade(pnl):
    c=db.conn(); c.execute("INSERT INTO trades(position_id,symbol,side,entry_price,exit_price,quantity,fees,pnl,exit_reason,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",(1,'BTC/USDT','BUY',100,100,1,0,pnl,'TEST',db.now())); c.commit(); c.close()

def test_approved_clean():
    reset(); r=AdvancedRiskGuard().evaluate(decision(),10000); assert r.approved and r.quantity>0

def test_daily_frequency_limit():
    reset()
    for _ in range(8): add_trade(1)
    r=AdvancedRiskGuard().evaluate(decision(),10000); assert not r.approved and 'frequency' in r.reason.lower()

def test_consecutive_loss_cooldown():
    reset()
    for _ in range(3): add_trade(-1)
    r=AdvancedRiskGuard().evaluate(decision(),10000); assert not r.approved and 'cooldown' in r.reason.lower(); assert db.state('paused')=='1'

def test_emergency_stop_blocks():
    reset(); db.set_state('emergency_stop','1'); r=AdvancedRiskGuard().evaluate(decision(),10000); assert not r.approved and 'Emergency' in r.reason

def test_safe_mode_blocks():
    reset(); db.set_state('safe_mode','1'); r=AdvancedRiskGuard().evaluate(decision(),10000); assert not r.approved and 'Safe mode' in r.reason
