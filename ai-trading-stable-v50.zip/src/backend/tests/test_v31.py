from app.certification_v31 import PaperCertificationV31

def test_final_paper_certification():
    r=PaperCertificationV31().run()
    assert r['certified'] is True
    assert r['live_enabled'] is False
    assert r['passed']==r['total']==15
