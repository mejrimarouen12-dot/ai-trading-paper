from fastapi.testclient import TestClient
from app.main import app

client=TestClient(app)

def test_dashboard_contract():
    r=client.get('/v29/dashboard'); assert r.status_code==200
    d=r.json(); assert d['mode']=='PAPER'; assert d['live_enabled'] is False
    for k in ['current','trades','positions','decisions','events','audits','performance','system']: assert k in d

def test_health_contract():
    r=client.get('/v29/health'); assert r.status_code==200
    d=r.json(); assert d['mode']=='PAPER'; assert d['live_enabled'] is False

def test_events_limit():
    r=client.get('/v29/events?limit=3'); assert r.status_code==200; assert len(r.json()['events'])<=3
