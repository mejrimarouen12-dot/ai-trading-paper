from app import db, config
from app.risk_guard_v12 import RiskGuard

def reset():
    db.init_db(); c=db.conn(); c.execute('DELETE FROM trades'); c.execute('DELETE FROM equity'); c.execute('DELETE FROM positions'); c.commit(); c.close(); db.set_state('cash','10000'); db.set_state('safe_mode','0'); db.set_state('paused','0'); db.set_state('emergency_stop','0'); db.set_state('risk_day',''); db.set_state('risk_day_start_equity','10000')

def decision(**kw):
    d={'decision':'BUY','confidence':0.80,'entry':100.0,'stop_loss':95.0,'take_profit':110.0}; d.update(kw); return d

def test_valid_sizing_approved():
    reset(); r=RiskGuard().evaluate(decision(),10000); assert r.approved and r.quantity>0 and r.quantity*100 <= 2000

def test_daily_loss_blocks_and_pauses():
    reset();
    c=db.conn(); c.execute("INSERT INTO trades(position_id,symbol,side,entry_price,exit_price,quantity,fees,pnl,exit_reason,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",(1,'BTC/USDT','BUY',100,90,1,0,-250,'STOP_LOSS',db.now())); c.commit(); c.close()
    r=RiskGuard().evaluate(decision(),10000); assert not r.approved; assert r.reason=='Daily loss limit reached'; assert db.state('paused')=='1'

def test_drawdown_blocks_and_safe_mode():
    reset();
    c=db.conn(); c.execute("INSERT INTO equity(balance,equity,created_at) VALUES(?,?,?)",(10000,10000,db.now())); c.execute("INSERT INTO equity(balance,equity,created_at) VALUES(?,?,?)",(9000,9400,db.now())); c.commit(); c.close(); db.set_state('cash','9400')
    r=RiskGuard().evaluate(decision(),9400); assert not r.approved; assert r.reason=='Maximum drawdown limit reached'; assert db.state('safe_mode')=='1'

def test_bad_rr_and_confidence_block():
    reset(); assert not RiskGuard().evaluate(decision(take_profit=101),10000).approved; assert not RiskGuard().evaluate(decision(confidence=0.5),10000).approved
