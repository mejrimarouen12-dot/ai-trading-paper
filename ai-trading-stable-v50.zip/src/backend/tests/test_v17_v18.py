from app.decision_validator_v17 import DecisionValidatorV17
from app.regime_v18 import MarketRegimeEngineV18
from app.market import MarketEngine

def test_validator_hold():
    r=DecisionValidatorV17().validate({'decision':'HOLD','confidence':.7}); assert r.valid

def test_validator_buy_geometry():
    r=DecisionValidatorV17().validate({'decision':'BUY','confidence':.8,'entry':100,'stop_loss':99,'take_profit':102,'thesis':'x','invalidation_condition':'y'}); assert r.valid

def test_validator_reject_bad_geometry():
    r=DecisionValidatorV17().validate({'decision':'BUY','confidence':.8,'entry':100,'stop_loss':101,'take_profit':102,'thesis':'x','invalidation_condition':'y'}); assert not r.valid

def test_regime_known():
    s=MarketEngine().snapshot('BTC/USDT'); r=MarketRegimeEngineV18().classify(s); assert r.regime in {'TRENDING_UP','TRENDING_DOWN','RANGING','HIGH_VOLATILITY','TRANSITION','UNKNOWN'}

def test_regime_invalid():
    class X: quality=False; price=0; atr=0
    r=MarketRegimeEngineV18().classify(X()); assert r.regime=='UNKNOWN' and not r.trade_allowed
