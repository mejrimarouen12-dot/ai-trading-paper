from app.expert_council_v16 import ExpertCouncil
from app.market import MarketEngine, Snapshot

def up():
    return Snapshot('BTC/USDT',100,98,95,60,1,1.2,'TREND_UP',True)

def down():
    return Snapshot('BTC/USDT',100,102,105,40,1,1.2,'TREND_DOWN',True)

def test_bullish_council():
    r=ExpertCouncil().evaluate(up(),'BUY')
    assert r.decision=='BUY' and r.consensus>=.60

def test_bearish_council():
    r=ExpertCouncil().evaluate(down(),'SELL')
    assert r.decision=='SELL'

def test_hold_on_stretched_buy():
    s=Snapshot('BTC/USDT',100,98,95,75,1,1.2,'TREND_UP',True)
    r=ExpertCouncil().evaluate(s,'BUY')
    assert r.decision=='HOLD' and r.contrarian_risk=='High'

def test_invalid_market_holds():
    s=Snapshot('BTC/USDT',0,0,0,50,0,0,'RANGE',False)
    r=ExpertCouncil().evaluate(s,'BUY')
    assert r.decision=='HOLD'

def test_high_volatility_risk_veto():
    s=Snapshot('BTC/USDT',100,98,95,60,5,1.2,'TREND_UP',True)
    r=ExpertCouncil().evaluate(s,'BUY')
    assert r.decision=='HOLD'
