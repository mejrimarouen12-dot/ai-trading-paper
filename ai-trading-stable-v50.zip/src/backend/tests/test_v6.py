from app import db
from app.health import snapshot, heartbeat
from app.supervisor import record_failure, record_success

def test_health_and_heartbeat():
    db.init_db(); heartbeat(); h=snapshot()
    assert h['mode']=='PAPER' and h['live_enabled'] is False and h['heartbeat_at']

def test_failure_counter_resets():
    db.init_db(); db.set_state('worker_consecutive_errors','0')
    record_failure(Exception('x'))
    assert db.state('worker_consecutive_errors')=='1'
    record_success()
    assert db.state('worker_consecutive_errors')=='0'
