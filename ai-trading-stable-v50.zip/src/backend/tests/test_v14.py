from types import SimpleNamespace
from app import db
from app.quality_v14 import SetupQualityEngine

def reset():
    db.init_db(); c=db.conn(); c.execute('DELETE FROM decisions'); c.execute('DELETE FROM setup_quality'); c.commit(); c.close()

def snap():
    return SimpleNamespace(symbol='BTC/USDT',price=60000,ema20=60100,ema50=59500,rsi=60,atr=900,volume_ratio=1.2,regime='TREND_UP',quality=True)

def decision():
    return {'decision':'BUY','confidence':0.8,'entry':60000,'stop_loss':58650,'take_profit':62700,'contrarian_risk':'Volatility reversal risk'}

def test_quality_approves_strong_setup():
    reset(); r=SetupQualityEngine().evaluate(snap(),decision()); assert r.approved and r.score >= .70

def test_quality_rejects_bad_trend():
    reset(); s=snap(); s.ema20=59000; r=SetupQualityEngine().evaluate(s,decision()); assert not r.approved

def test_quality_rejects_low_rr():
    reset(); d=decision(); d['take_profit']=60600; r=SetupQualityEngine().evaluate(snap(),d); assert not r.approved

def test_quality_rejects_bad_market():
    reset(); s=snap(); s.quality=False; r=SetupQualityEngine().evaluate(s,decision()); assert not r.approved

def test_quality_holds_non_executable():
    reset(); d=decision(); d['decision']='HOLD'; r=SetupQualityEngine().evaluate(snap(),d); assert not r.approved
