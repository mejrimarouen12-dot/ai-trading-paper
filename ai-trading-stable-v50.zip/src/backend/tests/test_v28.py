from app.data import Candle
from app.backtest_v28 import AdvancedBacktesterV28

def cs(n=120):
    out=[]; p=100
    for i in range(n):
        o=p; c=p+0.4; h=c+0.3; l=o-0.3
        out.append(Candle(i*300_000,o,h,l,c,10)); p=c
    return out

def sig(history):
    c=history[-1]
    if len(history)<10: return {'decision':'HOLD'}
    return {'decision':'BUY','entry':c.close,'stop_loss':c.close-1,'take_profit':c.close+2}

def test_candle_by_candle_and_metrics():
    r=AdvancedBacktesterV28().run(cs(),sig)
    assert r.lookahead_safe is True
    assert r.bars==120
    assert r.starting_balance==10000
    assert r.trades>=1

def test_stress_suite_has_required_cases():
    out=AdvancedBacktesterV28().stress_suite(cs(),sig)
    assert set(out)=={'base','high_volatility','low_volatility','downside_shock','upside_shock'}
    assert all(x['lookahead_safe'] for x in out.values())

def test_slippage_and_fees_are_nonnegative():
    r=AdvancedBacktesterV28(fee_rate=.001,slippage_bps=5).run(cs(),sig)
    assert r.fees>=0
