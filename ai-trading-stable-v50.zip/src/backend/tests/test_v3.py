from app.data import Candle
from app.walkforward import run_walk_forward

def test_walk_forward_runs():
    cs=[]; p=100
    for i in range(500):
        p += 0.05 if i%7 else -0.02
        cs.append(Candle(i*300000,p,p+1,p-1,p,1000))
    r=run_walk_forward(cs,100,100)
    assert r.folds>=2
