from app.chaos import ChaosLab, Fault
from app.integrity import IntegrityEngine

def test_all_chaos_faults_fail_safe():
    results=ChaosLab().run_all()
    assert len(results)==8
    assert all(r.safe for r in results)

def test_order_integrity():
    e=IntegrityEngine()
    assert e.validate_order(order_id="x",symbol="BTC/USDT",side="BUY",quantity=1,price=100)==[]
    assert "invalid_quantity" in e.validate_order(order_id="x",symbol="BTC/USDT",side="BUY",quantity=0,price=100)
