import os
from app.release_v33 import ReleasePreflight

def test_release_preflight_defaults_to_paper(monkeypatch):
    for k in ("TRADING_MODE", "LIVE_TRADING", "ALLOW_WITHDRAWALS", "BINANCE_SECRET_KEY", "EXCHANGE_SECRET_KEY"):
        monkeypatch.delenv(k, raising=False)
    checks = ReleasePreflight.run()
    assert all(c.ok for c in checks)

def test_release_rejects_live(monkeypatch):
    monkeypatch.setenv("LIVE_TRADING", "true")
    assert not all(c.ok for c in ReleasePreflight.run())

def test_release_rejects_non_paper(monkeypatch):
    monkeypatch.setenv("TRADING_MODE", "LIVE")
    assert not all(c.ok for c in ReleasePreflight.run())
