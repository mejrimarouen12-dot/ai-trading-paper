from app.portfolio_intelligence_v23 import PortfolioIntelligenceV23, Exposure
from app.expert_memory_v23 import ExpertMemoryV23
from app.validation_v23 import DecisionValidatorV23
from app.walkforward_v23 import windows

def test_correlated_exposure_blocks():
    p=PortfolioIntelligenceV23(max_correlated_weight=.10)
    r=p.assess(10000,[Exposure('BTC/USDT','BUY',2000,.2)],Exposure('ETH/USDT','BUY',2000,.2))
    assert not r.approved and 'CORRELATED_EXPOSURE_LIMIT' in r.reasons

def test_risk_budget_blocks():
    r=PortfolioIntelligenceV23(risk_budget=.02).assess(10000,[],Exposure('BTC/USDT','BUY',300,.03))
    assert not r.approved

def test_correlation_matrix():
    m=PortfolioIntelligenceV23().correlation_matrix(['BTC/USDT','ETH/USDT'])
    assert m['BTC/USDT']['BTC/USDT']==1 and m['BTC/USDT']['ETH/USDT']==.85

def test_memory_review_and_lessons():
    m=ExpertMemoryV23(); m.record(decision_id='D1',symbol='BTC/USDT',decision='BUY',regime='TRENDING_UP',thesis='breakout',invalidation='below support')
    m.close('D1',120,'WIN','breakout confirmed')
    r=m.review(); assert r['wins']==1 and len(r['lessons'])==1

def test_validator_accepts_structured_trade():
    ok,reason=DecisionValidatorV23().validate({'decision':'BUY','confidence':.8,'entry':100,'stop_loss':95,'take_profit':112,'thesis':'trend continuation','invalidation_condition':'close below 95'})
    assert ok and reason=='OK'

def test_validator_rejects_bad_rr():
    ok,_=DecisionValidatorV23().validate({'decision':'BUY','confidence':.8,'entry':100,'stop_loss':95,'take_profit':106,'thesis':'x','invalidation_condition':'y'})
    assert not ok

def test_hold_is_valid_without_trade_fields():
    assert DecisionValidatorV23().validate({'decision':'HOLD'})==(True,'OK')

def test_walkforward_windows_are_ordered():
    ws=windows(300,100,50,50); assert len(ws)==4; assert ws[0].train_end==ws[0].test_start
