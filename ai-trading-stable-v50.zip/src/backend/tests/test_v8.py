from app.certification import PaperCertification

def test_paper_certification_passes():
    r = PaperCertification().run()
    assert r["certified"] is True
    assert r["passed"] == r["total"]
