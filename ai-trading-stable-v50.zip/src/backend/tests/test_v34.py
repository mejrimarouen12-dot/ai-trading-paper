from app import db
from app.runner_v34 import PaperRunnerV34

class FakeReport:
    status = "OK"
    market_source = "test"
    symbols_checked = 1
    decisions = 1
    executed = 0
    rejected = 0
    closed = 0
    error = ""

class FakeSession:
    def run_cycle(self): return FakeReport()

def setup_function():
    db.init_db()
    for k,v in {"paused":"0","safe_mode":"0","emergency_stop":"0","paper_runner_lock":"0","paper_runner_stop":"0","paper_runner_cycles":"0","paper_runner_last_at":"","paper_runner_last_status":""}.items(): db.set_state(k,v)

def test_status_idle_and_paper_only():
    s = PaperRunnerV34(FakeSession()).status()
    assert s.state == "IDLE"
    assert s.live_enabled is False

def test_run_once_updates_persistent_state():
    r = PaperRunnerV34(FakeSession()).run_once()
    assert r["status"] == "OK"
    assert r["cycle"] == 1
    assert db.state("paper_runner_cycles") == "1"
    assert db.state("paper_runner_lock") == "0"

def test_stop_request_is_observed():
    runner = PaperRunnerV34(FakeSession())
    runner.request_stop()
    assert runner.status().state == "STOP_REQUESTED"

def test_bounded_runner_has_hard_cycle_cap():
    out = PaperRunnerV34(FakeSession()).run_bounded(cycles=99999, interval_seconds=0)
    assert out["requested_cycles"] == 1440
    assert out["completed_cycles"] == 1440
