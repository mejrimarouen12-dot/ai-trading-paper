from app import db
from app.scheduler_v11 import PaperScheduler
from app.reports_v11 import daily_report, weekly_report, recovery_status

class FakeSession:
    def __init__(self): self.n=0
    def run_cycle(self):
        from app.paper_session import CycleReport
        self.n+=1
        return CycleReport('OK','test',0,0,0,0,0)

def reset():
    db.init_db(); db.set_state('cash','10000'); db.set_state('safe_mode','0'); db.set_state('paused','0'); db.set_state('emergency_stop','0')

def test_scheduler_run_once_and_status():
    reset(); s=PaperScheduler(interval_seconds=2,session=FakeSession()); r=s.run_once(); st=s.status()
    assert r.status=='OK'; assert st.cycles==1; assert st.successes==1; assert st.failures==0

def test_scheduler_start_stop():
    reset(); s=PaperScheduler(interval_seconds=1,session=FakeSession()); assert s.start() is True; assert s.stop() is True

def test_reports_safe_on_empty_history():
    reset(); d=daily_report(); w=weekly_report()
    assert d['trade_count']==0 and w['trade_count']==0
    assert 'return_pct' in d and 'return_pct' in w

def test_recovery_status_contract():
    reset(); r=recovery_status(); assert r['safe_mode'] is False; assert r['paused'] is False; assert r['emergency_stop'] is False; assert isinstance(r['recent_errors'],list)
