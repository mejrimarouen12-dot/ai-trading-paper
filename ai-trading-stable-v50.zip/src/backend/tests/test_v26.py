from app.data import Candle
from app.market_reliability_v26 import MarketDataValidatorV26,FailoverMarketFeedV26,DataStatus

def candles(n=4,start=1_000_000,step=300_000):
    return [Candle(start+i*step,100+i,101+i,99+i,100.5+i,10) for i in range(n)]

def test_valid_fresh_data():
    q=MarketDataValidatorV26().validate(candles(),1_900_000,'primary'); assert q.ok and q.status==DataStatus.FRESH

def test_stale_data_blocks():
    cs=candles(); q=MarketDataValidatorV26().validate(cs,cs[-1].ts+90_001,'primary'); assert not q.ok and q.status==DataStatus.STALE

def test_bad_ohlc_blocks():
    cs=candles(); cs[2]=Candle(cs[2].ts,100,90,99,100,10); q=MarketDataValidatorV26().validate(cs,cs[-1].ts,'primary'); assert not q.ok

def test_gap_blocks():
    cs=candles(); cs[2]=Candle(cs[2].ts+1_000_000,102,103,101,102,10); q=MarketDataValidatorV26().validate(cs,cs[-1].ts,'primary'); assert not q.ok and any('GAP' in x for x in q.issues)

def test_primary_failover():
    cs=candles(); f=FailoverMarketFeedV26(lambda: (_ for _ in ()).throw(RuntimeError('primary down')),lambda:cs); r=f.fetch(cs[-1].ts); assert r.source=='secondary' and r.candles==cs and f.last_quality.ok

def test_invalid_primary_uses_secondary():
    good=candles(); bad=good.copy(); bad[1]=Candle(bad[1].ts,100,90,99,100,10); f=FailoverMarketFeedV26(lambda:bad,lambda:good); r=f.fetch(good[-1].ts); assert r.source=='secondary'

def test_all_sources_fail_safe():
    cs=candles(); bad=bad2=cs.copy(); bad[0]=Candle(bad[0].ts,100,90,99,100,10); bad2[0]=Candle(bad2[0].ts,100,90,99,100,10); f=FailoverMarketFeedV26(lambda:bad,lambda:bad2); r=f.fetch(cs[-1].ts); assert r.candles is None and f.last_quality.status==DataStatus.UNAVAILABLE

def test_duplicate_timestamp_blocks():
    cs=candles(); cs[2]=Candle(cs[1].ts,102,103,101,102,10); q=MarketDataValidatorV26().validate(cs,cs[-1].ts,'x'); assert not q.ok

def test_negative_volume_blocks():
    cs=candles(); cs[2]=Candle(cs[2].ts,102,103,101,102,-1); q=MarketDataValidatorV26().validate(cs,cs[-1].ts,'x'); assert not q.ok
