from app.release_v50 import ReleaseV50


def test_v50_manifest_is_paper_only(monkeypatch):
    for k in ("MODE", "LIVE_TRADING", "ALLOW_WITHDRAWALS", "BINANCE_SECRET_KEY", "EXCHANGE_SECRET_KEY", "EXCHANGE_API_SECRET"):
        monkeypatch.delenv(k, raising=False)
    m = ReleaseV50.manifest()
    assert m["version"] == "50.0"
    assert m["mode"] == "PAPER"
    assert m["live_enabled"] is False
    assert m["withdrawals_enabled"] is False
    assert m["ready"] is True


def test_v50_rejects_live_environment(monkeypatch):
    monkeypatch.setenv("LIVE_TRADING", "true")
    assert not ReleaseV50.manifest()["ready"]


def test_v50_rejects_withdrawals(monkeypatch):
    monkeypatch.setenv("ALLOW_WITHDRAWALS", "true")
    assert not ReleaseV50.manifest()["ready"]
