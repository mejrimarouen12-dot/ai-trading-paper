from app.paper_session import PaperSession
from app.market import Snapshot
from app import db

class Feed:
    def snapshot(self,symbol,timeframe='5m'):
        return Snapshot(symbol,100.0,101.0,99.0,58.0,2.0,1.2,'TREND_UP',True)

def test_v9_market_source_is_paper_only():
    from app.api_v9 import market_source
    x=market_source(); assert x['execution']=='PAPER_ONLY' and x['live_orders'] is False

def test_v9_cycle_runs_with_injected_feed():
    db.init_db(); db.set_state('safe_mode','0'); db.set_state('paused','0'); db.set_state('emergency_stop','0'); db.set_state('cash','10000')
    r=PaperSession(feed=Feed()).run_cycle()
    assert r.status=='OK'; assert r.decisions==3; assert r.market_source=='real_public'

def test_v9_bad_feed_enters_safe_mode():
    class Bad:
        def snapshot(self,*a,**k): raise RuntimeError('feed failure')
    db.init_db(); db.set_state('safe_mode','0')
    r=PaperSession(feed=Bad()).run_cycle()
    assert r.status=='SAFE_MODE'; assert db.state('safe_mode')=='1'
