from app.adaptive_strategy_v19 import AdaptiveStrategyEngineV19

def test_uptrend_accepts_aligned_setup():
    r=AdaptiveStrategyEngineV19().evaluate('TRENDING_UP','BUY',.80,.75,2.2)
    assert r.approved and r.action=='BUY'

def test_uptrend_rejects_short():
    r=AdaptiveStrategyEngineV19().evaluate('TRENDING_UP','SELL',.90,.90,3.0)
    assert not r.approved and r.action=='HOLD'

def test_downtrend_accepts_aligned_setup():
    r=AdaptiveStrategyEngineV19().evaluate('TRENDING_DOWN','SELL',.80,.75,2.2)
    assert r.approved

def test_high_volatility_blocks():
    r=AdaptiveStrategyEngineV19().evaluate('HIGH_VOLATILITY','BUY',.99,.99,5)
    assert not r.approved and r.action=='HOLD'

def test_transition_blocks():
    r=AdaptiveStrategyEngineV19().evaluate('TRANSITION','SELL',.99,.99,5)
    assert not r.approved

def test_range_is_defined_but_safety_blocks():
    p=AdaptiveStrategyEngineV19().policy('RANGING')
    r=AdaptiveStrategyEngineV19().evaluate('RANGING','BUY',.99,.99,5)
    assert p.style=='mean-reversion' and not r.approved

def test_quality_threshold():
    r=AdaptiveStrategyEngineV19().evaluate('TRENDING_UP','BUY',.69,.90,3)
    assert not r.approved

def test_confidence_threshold():
    r=AdaptiveStrategyEngineV19().evaluate('TRENDING_UP','BUY',.90,.64,3)
    assert not r.approved

def test_rr_threshold():
    r=AdaptiveStrategyEngineV19().evaluate('TRENDING_UP','BUY',.90,.90,1.99)
    assert not r.approved

def test_unknown_is_safe():
    r=AdaptiveStrategyEngineV19().evaluate('SOMETHING_ELSE','BUY',1,1,10)
    assert not r.approved and r.policy.regime=='UNKNOWN'

def test_hold_is_not_executable():
    r=AdaptiveStrategyEngineV19().evaluate('TRENDING_UP','HOLD',1,1,10)
    assert not r.approved and r.action=='HOLD'
