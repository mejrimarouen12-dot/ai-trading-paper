from app import db
from app.intelligence import record_decision_audit, replay_decision, trade_memory

def test_replay_and_memory(tmp_path):
    db.DB_PATH = tmp_path/'test.db'
    db.init_db()
    c=db.conn(); c.execute("INSERT INTO decisions(symbol,decision,confidence,regime,reason,created_at) VALUES('BTC/USDT','HOLD',0.7,'SIDEWAYS','test',?)",(db.now(),)); c.commit(); c.close()
    did=record_decision_audit('BTC/USDT',{'decision':'HOLD'}, {'price':100}, 'HOLD')
    assert replay_decision(did)['decision']['decision']=='HOLD'
    assert trade_memory()['count']==0
