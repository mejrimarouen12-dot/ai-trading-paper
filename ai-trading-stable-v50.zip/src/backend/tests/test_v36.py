from types import SimpleNamespace
from datetime import datetime, timezone
from app import db
from app.operations_v36 import PaperOperationsV36

def setup_function():
    db.init_db()
    c=db.conn(); c.execute('DELETE FROM paper_cycles'); c.commit(); c.close()

def test_cycle_is_recorded_and_summarized():
    ops=PaperOperationsV36()
    report=SimpleNamespace(status='OK', decisions=3, executed=1, rejected=2, closed=1)
    stamp=datetime.now(timezone.utc).isoformat()
    ops.record_cycle(1, report, stamp, stamp)
    h=ops.history()
    assert len(h)==1 and h[0]['cycle']==1 and h[0]['executed']==1
    s=ops.summary()
    assert s['cycles_recorded']==1 and s['decisions']==3 and s['live_enabled'] is False

def test_history_limit_is_bounded():
    ops=PaperOperationsV36()
    report=SimpleNamespace(status='HOLD', decisions=1, executed=0, rejected=0, closed=0)
    stamp=datetime.now(timezone.utc).isoformat()
    for i in range(3): ops.record_cycle(i+1, report, stamp, stamp)
    assert len(ops.history(2))==2
    assert len(ops.history(9999))==3
