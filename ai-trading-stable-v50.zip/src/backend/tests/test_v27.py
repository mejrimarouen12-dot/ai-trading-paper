from app.data import Candle
from app.scanner_v27 import MarketScannerV27

def candles(n=40, start=1_000_000, step=300_000, trend=0.5, volume=10):
    out=[]
    price=100.0
    for i in range(n):
        o=price; c=price+trend; h=max(o,c)+0.5; l=min(o,c)-0.5
        out.append(Candle(start+i*step,o,h,l,c,volume*(2 if i==n-1 else 1)))
        price=c
    return out

def test_scanner_ranks_without_execution():
    cs=candles(trend=1.0)
    r=MarketScannerV27().scan({'BTC/USDT':lambda:cs},cs[-1].ts)
    assert r.scanned==1 and len(r.candidates)==1
    assert r.candidates[0].signal in ('BUY','HOLD')

def test_bad_data_blocked():
    cs=candles(); cs[-1]=Candle(cs[-1].ts,100,90,99,100,10)
    r=MarketScannerV27().scan({'BTC/USDT':lambda:cs},cs[-1].ts)
    assert 'BTC/USDT' in r.blocked and not r.candidates

def test_stale_data_blocked():
    cs=candles(); r=MarketScannerV27().scan({'BTC/USDT':lambda:cs},cs[-1].ts+100_000)
    assert 'BTC/USDT' in r.blocked

def test_multi_asset_scan():
    cs=candles(trend=0.4); ds=candles(trend=-0.4)
    r=MarketScannerV27().scan({'BTC/USDT':lambda:cs,'ETH/USDT':lambda:ds},cs[-1].ts)
    assert r.scanned==2 and len(r.candidates)==2

def test_no_order_execution_interface():
    assert not hasattr(MarketScannerV27(),'place_order')
