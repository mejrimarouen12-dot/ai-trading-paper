from fastapi import APIRouter
from .market import MarketEngine
from .expert_council_v16 import ExpertCouncil
from .expert_brain_v17 import ExpertBrainV17
router=APIRouter(prefix='/v17',tags=['v17-expert-brain'])
@router.get('/brain')
def brain(symbol:str='BTC/USDT'):
    s=MarketEngine().snapshot(symbol); c=ExpertCouncil().evaluate(s); r=ExpertBrainV17().synthesize(c)
    return {'mode':'PAPER','live_orders':False,'symbol':symbol,'decision':r.decision,'valid':r.valid,'reason':r.reason}
