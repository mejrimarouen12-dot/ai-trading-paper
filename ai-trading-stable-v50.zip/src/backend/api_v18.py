from fastapi import APIRouter
from .market import MarketEngine
from .regime_v18 import MarketRegimeEngineV18
router=APIRouter(prefix='/v18',tags=['v18-regime'])
@router.get('/regime')
def regime(symbol:str='BTC/USDT'):
    s=MarketEngine().snapshot(symbol); r=MarketRegimeEngineV18().classify(s)
    return {'mode':'PAPER','live_orders':False,'symbol':symbol,'regime':r.regime,'confidence':r.confidence,'trade_allowed':r.trade_allowed,'reason':r.reason}
